"""
cost_tracker.py — تتبع تكلفة API على مستوى الرسالة، المحادثة، والمستخدم
"""

from datetime import datetime
from db import get_db

# ── أسعار النماذج (بالدولار لكل مليون token) ─────────────────────────────────
PRICING = {
    # Groq LLaMA
    "llama-3.3-70b-versatile": {
        "input_per_M":  0.59,   # $0.59 / 1M input tokens
        "output_per_M": 0.79,   # $0.79 / 1M output tokens
    },
    # fallback / cheaper model
    "llama-3.1-8b-instant": {
        "input_per_M":  0.05,
        "output_per_M": 0.08,
    },
    # Embeddings (keyword-based = $0)
    "keyword": {
        "input_per_M": 0.0,
        "output_per_M": 0.0,
    },
}


def calc_cost(model: str, input_tokens: int, output_tokens: int) -> dict:
    """calculate cost of one message and return full details."""
    prices = PRICING.get(model, PRICING["llama-3.3-70b-versatile"])
    input_cost  = (input_tokens  / 1_000_000) * prices["input_per_M"]
    output_cost = (output_tokens / 1_000_000) * prices["output_per_M"]
    total_cost  = input_cost + output_cost

    return {
        "model":         model,
        "input_tokens":  input_tokens,
        "output_tokens": output_tokens,
        "input_cost":    round(input_cost,  6),
        "output_cost":   round(output_cost, 6),
        "total_cost":    round(total_cost,  6),
        "input_price_per_M":  prices["input_per_M"],
        "output_price_per_M": prices["output_per_M"],
    }


def save_cost_record(
    user_id:       str,
    conversation_id: str,
    model:         str,
    input_tokens:  int,
    output_tokens: int,
    optimized:     bool = False,
    trace_steps:   list = None,
) -> dict:
    """
    calculate cost and save the log in MongoDB.
    return a dict containing all cost details.
    """
    cost_info = calc_cost(model, input_tokens, output_tokens)
    record = {
        "user_id":         user_id,
        "conversation_id": conversation_id,
        "timestamp":       datetime.utcnow().isoformat(),
        "optimized":       optimized,
        "trace_steps":     trace_steps or [],
        **cost_info,
    }
    try:
        db = get_db()
        db["cost_logs"].insert_one(record)
    except Exception:
        pass  # don't stop the application if MongoDB is not available
    return record


def get_cost_stats():
    """cost stats for the dashboard."""
    try:
        db = get_db()
        logs = list(db["cost_logs"].find({}, {"_id": 0}))
    except Exception:
        return {"error": "MongoDB not available"}

    if not logs:
        return {
            "total_messages": 0,
            "total_cost": 0,
            "avg_cost_per_message": 0,
            "by_user": {},
            "by_conversation": {},
            "optimized_count": 0,
            "normal_count": 0,
            "optimized_total_cost": 0,
            "normal_total_cost": 0,
        }

    total_cost   = sum(r.get("total_cost", 0) for r in logs)
    opt_logs     = [r for r in logs if r.get("optimized")]
    normal_logs  = [r for r in logs if not r.get("optimized")]

    # aggregate by user
    by_user = {}
    for r in logs:
        uid = r.get("user_id", "unknown")
        by_user.setdefault(uid, {"messages": 0, "total_cost": 0, "input_tokens": 0, "output_tokens": 0})
        by_user[uid]["messages"]      += 1
        by_user[uid]["total_cost"]    += r.get("total_cost", 0)
        by_user[uid]["input_tokens"]  += r.get("input_tokens", 0)
        by_user[uid]["output_tokens"] += r.get("output_tokens", 0)

    # aggregate by conversation
    by_conv = {}
    for r in logs:
        cid = r.get("conversation_id", "unknown")
        by_conv.setdefault(cid, {"messages": 0, "total_cost": 0})
        by_conv[cid]["messages"]   += 1
        by_conv[cid]["total_cost"] += r.get("total_cost", 0)

    return {
        "total_messages":        len(logs),
        "total_cost":            round(total_cost, 6),
        "avg_cost_per_message":  round(total_cost / len(logs), 6) if logs else 0,
        "by_user":               by_user,
        "by_conversation":       by_conv,
        "optimized_count":       len(opt_logs),
        "normal_count":          len(normal_logs),
        "optimized_total_cost":  round(sum(r.get("total_cost", 0) for r in opt_logs), 6),
        "normal_total_cost":     round(sum(r.get("total_cost", 0) for r in normal_logs), 6),
        "recent_logs":           logs[-20:][::-1],  # last 20 logs
    }


def get_conversation_cost(conversation_id: str) -> dict:
    """cost of one conversation."""
    try:
        db = get_db()
        logs = list(db["cost_logs"].find(
            {"conversation_id": conversation_id}, {"_id": 0}
        ))
    except Exception:
        return {"total_cost": 0, "messages": 0}

    return {
        "conversation_id": conversation_id,
        "messages":       len(logs),
        "total_cost":     round(sum(r.get("total_cost", 0) for r in logs), 6),
        "total_input":    sum(r.get("input_tokens", 0) for r in logs),
        "total_output":   sum(r.get("output_tokens", 0) for r in logs),
    }
