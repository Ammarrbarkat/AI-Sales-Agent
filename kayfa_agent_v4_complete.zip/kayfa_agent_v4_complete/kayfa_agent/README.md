# Kayfa AI Sales Agent — Week 3 Task: Agentic AI Internship @ Kayfa

> وكيل مبيعات ذكي لأكاديمية Kayfa مع مراقبة تكلفة كاملة وتتبع سلوك وحلقة تحسين.

---

## 🚀 كيفية التشغيل

```bash
# 1. انسخ المتغيرات البيئية
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# وأضف: GROQ_API_KEY و MONGODB_URI

# 2. ثبّت المكتبات
pip install -r requirements.txt

# 3. شغّل التطبيق
streamlit run app_ai.py
```

---

## 📄 الصفحات

| الصفحة | الوصف |
|--------|--------|
| `app_ai.py` | صفحة المحادثة الرئيسية + Behaviour Trace + Cost Badge |
| `pages/crm_dashboard.py` | تذاكر CRM للمبيعات |
| `pages/admin_dashboard.py` | لوحة تحكم المسؤول: Cost Monitor + Trace + Optimization |

---

## 🏗️ البنية التقنية

```
kayfa_agent/
├── app_ai.py              # الصفحة الرئيسية
├── agent.py               # وكيل المحادثة + Behaviour Trace
├── knowledge_base.py      # RAG بالـ Keyword Search
├── cost_tracker.py        # 💰 تتبع التكلفة (جديد)
├── db.py                  # MongoDB
├── crm.py                 # إدارة Leads
├── pages/
│   ├── crm_dashboard.py   # لوحة المبيعات
│   └── admin_dashboard.py # 📊 لوحة المسؤول (جديد)
└── data/
    ├── json/              # الكورسات والمسارات
    └── text/              # السياسات والدبلومات
```

---

## 💰 نموذج التكلفة

| النموذج | Input | Output |
|---------|-------|--------|
| llama-3.3-70b-versatile | $0.59/M | $0.79/M |
| llama-3.1-8b-instant | $0.05/M | $0.08/M |
| Keyword RAG | $0 | $0 |

### حلقة التحسين

**قبل:** رسالة واحدة = ~$0.0059  
**بعد (وضع محسَّن):** رسالة واحدة = ~$0.000224  
**توفير: 96.2%**

التحسينات المطبَّقة:
1. تقليص System Prompt من ~900 كلمة إلى ~80 كلمة
2. توجيه للنموذج الأرخص (8B بدل 70B)
3. RAG بالـ Keywords بدل Embeddings ($0 بدل $0.13/M)
4. تحديد max_tokens بـ 800 بدل 1000

---

## 🔑 المتغيرات البيئية

```env
GROQ_API_KEY=your_groq_key
MONGODB_URI=mongodb+srv://...
LOGIN_USERNAME=kayfa_admin
LOGIN_PASSWORD=kayfa2026
SALES_USERNAME=sales
SALES_PASSWORD=sales2026
```
