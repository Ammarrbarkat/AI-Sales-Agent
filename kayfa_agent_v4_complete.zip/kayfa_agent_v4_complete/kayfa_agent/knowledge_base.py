"""
knowledge_base.py
Simple keyword-based retrieval — no heavy ML dependencies.
"""

import json
import re
from pathlib import Path

DATA_JSON = Path("data/json")
DATA_TEXT = Path("data/text")


def load_all_chunks():
    chunks = []

    # JSON files
    for json_file in DATA_JSON.glob("*.json"):
        with open(json_file, encoding="utf-8") as f:
            items = json.load(f)
        for item in items:
            text = f"[{json_file.stem}]\n"
            for k, v in item.items():
                if isinstance(v, list):
                    text += f"{k}: {', '.join(map(str, v))}\n"
                else:
                    text += f"{k}: {v}\n"
            chunks.append({"source": json_file.stem, "text": text.strip()})

    # Markdown files
    for md_file in DATA_TEXT.glob("*.md"):
        with open(md_file, encoding="utf-8") as f:
            content = f.read()
        chunk_size = 800
        words = content.split()
        buf = []
        char_count = 0
        for word in words:
            buf.append(word)
            char_count += len(word) + 1
            if char_count >= chunk_size:
                chunks.append({"source": md_file.stem, "text": " ".join(buf)})
                buf = buf[-50:]
                char_count = sum(len(w) + 1 for w in buf)
        if buf:
            chunks.append({"source": md_file.stem, "text": " ".join(buf)})

    return chunks


def tokenize(text):
    return set(re.findall(r'\w+', text.lower()))


def retrieve(query, chunks, index=None, embedder=None, top_k=5):
    """Simple keyword overlap retrieval — no ML needed."""
    q_tokens = tokenize(query)
    scored = []
    for chunk in chunks:
        c_tokens = tokenize(chunk["text"])
        overlap = len(q_tokens & c_tokens)
        if overlap > 0:
            scored.append((overlap, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [{"score": s, **c} for s, c in scored[:top_k]]


def get_kb(embedder=None):
    """Return (chunks, None) — no index needed for keyword search."""
    chunks = load_all_chunks()
    return chunks, None
