"""
Kayfa RAG Engine
Loads all knowledge base files, builds FAISS index, and retrieves relevant context.
"""

import os
import json
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

DATA_JSON_DIR = os.path.join(os.path.dirname(__file__), "data", "json")
DATA_TEXT_DIR = os.path.join(os.path.dirname(__file__), "data", "text")

CHUNK_WORDS = 200
STEP_WORDS  = 100


def _load_json_files():
    chunks = []
    for fname, key in [("kayfa_courses.json", "courses"), ("kayfa_roadmaps.json", "roadmaps")]:
        fpath = os.path.join(DATA_JSON_DIR, fname)
        if not os.path.exists(fpath):
            continue
        with open(fpath, encoding="utf-8") as f:
            items = json.load(f)
        for item in items:
            parts = []
            for k, v in item.items():
                if isinstance(v, list):
                    v = ", ".join(str(x) for x in v)
                parts.append(f"{k}: {v}")
            chunks.append({"text": "\n".join(parts), "source": fname})
    return chunks


def _load_text_files():
    chunks = []
    if not os.path.exists(DATA_TEXT_DIR):
        return chunks
    for fname in os.listdir(DATA_TEXT_DIR):
        if not fname.endswith(".md"):
            continue
        fpath = os.path.join(DATA_TEXT_DIR, fname)
        with open(fpath, encoding="utf-8") as f:
            content = f.read()
        words = content.split()
        i = 0
        while i < len(words):
            chunk_text = " ".join(words[i:i + CHUNK_WORDS])
            chunks.append({"text": chunk_text, "source": fname})
            i += STEP_WORDS
    return chunks


class KayfaRAG:
    _instance = None

    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.chunks = []
        self.index = None
        self._build_index()

    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _build_index(self):
        self.chunks = _load_json_files() + _load_text_files()
        if not self.chunks:
            return
        texts = [c["text"] for c in self.chunks]
        embeddings = self.model.encode(texts, show_progress_bar=False).astype("float32")
        dim = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dim)
        self.index.add(embeddings)

    def retrieve(self, query: str, top_k: int = 6) -> str:
        if self.index is None or not self.chunks:
            return ""
        q_emb = self.model.encode([query]).astype("float32")
        _, indices = self.index.search(q_emb, top_k)
        seen, results = set(), []
        for idx in indices[0]:
            if idx < len(self.chunks):
                chunk = self.chunks[idx]
                key = chunk["text"][:80]
                if key not in seen:
                    seen.add(key)
                    results.append(f"[{chunk['source']}]\n{chunk['text']}")
        return "\n\n---\n\n".join(results)
