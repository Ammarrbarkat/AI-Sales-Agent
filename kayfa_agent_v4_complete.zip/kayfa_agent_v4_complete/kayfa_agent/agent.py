"""
agent.py — Kayfa AI Sales Agent with Behaviour Trace + Cost Tracking
"""

import os
import time
import json
from knowledge_base import retrieve

# ── System prompt (مختصر للتحسين) ───────────────────────────────────────────
SYSTEM_PROMPT_FULL = """أنت مساعد مبيعات ذكي لمنصة Kayfa التعليمية — منصة عربية رائدة في تعليم مهارات التكنولوجيا والبيانات والأمن السيبراني وتطوير الويب والذكاء الاصطناعي.

## هويتك
اسمك "كيفة" — مساعد Kayfa الذكي. أنت محترف، ودود، مقنع، وصادق دائماً.

## لغتك
- تحدث بالعربية مع أي عميل يبدأ بالعربية (مصري، سعودي، سوري).
- تحدث بالإنجليزية إذا بدأ العميل بالإنجليزية.
- لا تخلط اللغتين إلا للمصطلحات التقنية.

## مهمتك
1. اقرأ نية الزائر — مستكشف، مقارن، حساس للسعر، أو مستعد للتسجيل
2. أوصِ بالمنتج الصح من الـ knowledge base فقط — لا تخترع أسعاراً أو كورسات
3. اقنع بصدق — استخدم مزايا حقيقية وشهادات دولية وشركاء (Microsoft, GIZ)
4. استهدف الدبلومات — ابدأ بما يناسب العميل لكن اهدف للـ tracks والدبلومات
5. التقط الـ lead — عند إشارة شراء، اجمع بيانات العميل بطريقة طبيعية

## إشارات الشراء
- سأل عن السعر أو طريقة الدفع
- سأل عن موعد البدء أو المدة
- قال "مهتم" أو "عايز أعرف أكتر"
- قارن بين برنامجين

## عند التقاط الـ lead اجمع
الاسم، رقم الواتساب أو البريد، المدينة، المنتج المهتم به، مستواه، هدفه

## قواعد صارمة
- لا تخترع أسعاراً — استخدم الأسعار من الـ knowledge base فقط
- إذا لم تعرف إجابة قل "سأوصلك بفريق المبيعات على info@kayfa.io"
- لا تخرج عن دور مساعد مبيعات Kayfa

## Context من الـ knowledge base
{context}

## JSON للـ lead
إذا جمعت بيانات كافية، أضف في نهاية ردك هذا الـ JSON (لا تعرضه للعميل):
<LEAD_JSON>
{{"الاسم":"","التواصل":"","المدينة":"","المنتج_المهتم_به":"","الهدف":"","المستوى_الحالي":"","حرارة_العميل":"ساخن/دافئ/بارد","إشارات_الشراء":"","الاعتراضات":"","ملخص_المحادثة":"","الإجراء_التالي":""}}
</LEAD_JSON>
"""

# ── System prompt مختصر للتحسين (optimization) ─────────────────────────────
SYSTEM_PROMPT_OPTIMIZED = """أنت كيفة، مساعد مبيعات Kayfa الذكي. ردود مختصرة ومقنعة.
- استخدم معلومات الكورسات من الـ context فقط
- لا تخترع أسعار
- التقط Lead عند إشارة شراء

Context: {context}

إذا جمعت بيانات عميل كافية أضف: <LEAD_JSON>{{...}}</LEAD_JSON>"""

# ── Token estimator (بدون tiktoken) ─────────────────────────────────────────
def estimate_tokens(text: str) -> int:
    """تقدير عدد الـ tokens (كل 4 حروف ≈ token)."""
    return max(1, len(text) // 4)


def chat(messages: list, user_input: str, chunks, index,
         embedder=None, optimized: bool = False, conversation_id: str = ""):
    """
    إرسال رسالة للوكيل وإرجاع (reply, lead_data, trace, cost_info).
    trace = قائمة بخطوات التفكير للـ behaviour trace.
    """
    from groq import Groq

    trace = []
    t0 = time.time()

    # ── خطوة 1: RAG retrieval ────────────────────────────────────────────────
    trace.append({
        "step":   "1. RAG Retrieval",
        "icon":   "🔍",
        "detail": f"البحث عن: «{user_input[:60]}»",
        "type":   "tool_call",
    })
    context_docs = retrieve(user_input, chunks, index, embedder, top_k=5)
    sources = list({d["source"] for d in context_docs})
    context = "\n\n---\n".join(d["text"] for d in context_docs)

    trace.append({
        "step":   "2. نتيجة الاسترجاع",
        "icon":   "📚",
        "detail": f"وُجد {len(context_docs)} مقطع من: {', '.join(sources)}",
        "type":   "tool_result",
        "sources": sources,
        "tokens":  estimate_tokens(context),
    })

    # ── اختيار الـ system prompt ─────────────────────────────────────────────
    prompt_template = SYSTEM_PROMPT_OPTIMIZED if optimized else SYSTEM_PROMPT_FULL
    system = prompt_template.replace("{context}", context)
    model  = "llama-3.1-8b-instant" if optimized else "llama-3.3-70b-versatile"

    trace.append({
        "step":   "3. تجهيز الطلب",
        "icon":   "⚙️",
        "detail": f"النموذج: {model} | Prompt: {'مختصر ✅' if optimized else 'كامل'}",
        "type":   "reasoning",
        "optimized": optimized,
    })

    # ── حساب input tokens تقريبياً ──────────────────────────────────────────
    full_messages = [{
        "role": "system", "content": system
    }] + messages + [{"role": "user", "content": user_input}]

    input_text  = " ".join(m["content"] for m in full_messages)
    input_tokens_est = estimate_tokens(input_text)

    # ── خطوة 2: LLM call ─────────────────────────────────────────────────────
    api_key = os.getenv("GROQ_API_KEY", "")
    client  = Groq(api_key=api_key)

    trace.append({
        "step":   "4. إرسال الطلب للـ LLM",
        "icon":   "🤖",
        "detail": f"النموذج: {model} | tokens تقريبية: {input_tokens_est:,}",
        "type":   "reasoning",
    })

    response = client.chat.completions.create(
        model=model,
        messages=full_messages,
        max_tokens=800 if optimized else 1000,
        temperature=0.7,
    )

    raw           = response.choices[0].message.content
    input_tokens  = getattr(response.usage, "prompt_tokens",    input_tokens_est)
    output_tokens = getattr(response.usage, "completion_tokens", estimate_tokens(raw))
    elapsed       = round(time.time() - t0, 2)

    # ── استخراج الـ Lead JSON ─────────────────────────────────────────────────
    lead_data = None
    if "<LEAD_JSON>" in raw and "</LEAD_JSON>" in raw:
        start = raw.index("<LEAD_JSON>")  + len("<LEAD_JSON>")
        end   = raw.index("</LEAD_JSON>")
        try:
            lead_data = json.loads(raw[start:end].strip())
        except Exception:
            pass
        raw = raw[:raw.index("<LEAD_JSON>")].strip()

    trace.append({
        "step":   "5. الرد النهائي",
        "icon":   "💬",
        "detail": f"طول الرد: {len(raw)} حرف | {output_tokens} token | ⏱ {elapsed}s",
        "type":   "final_response",
        "lead_captured": lead_data is not None,
    })

    # ── حساب التكلفة ─────────────────────────────────────────────────────────
    from cost_tracker import calc_cost
    cost_info = calc_cost(model, input_tokens, output_tokens)
    cost_info["elapsed_s"] = elapsed

    # إضافة التكلفة للخطوات
    for step in trace:
        step["cost_usd"] = round(cost_info["total_cost"] / len(trace), 8)

    return raw, lead_data, trace, cost_info
