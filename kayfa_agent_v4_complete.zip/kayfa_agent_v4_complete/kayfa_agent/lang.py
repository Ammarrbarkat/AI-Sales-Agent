"""
lang.py — Bilingual UI system using query_params to persist across pages
"""

UI = {
    "sign_in":        {"ar": "تسجيل الدخول",   "en": "Sign In"},
    "username":       {"ar": "اسم المستخدم",    "en": "Username"},
    "password":       {"ar": "كلمة المرور",     "en": "Password"},
    "login_btn":      {"ar": "دخول",            "en": "Sign In"},
    "wrong_creds":    {"ar": "❌ اسم المستخدم أو كلمة المرور غلط", "en": "❌ Wrong username or password"},
    "current_session":{"ar": "الجلسة الحالية", "en": "Current Session"},
    "messages":       {"ar": "رسائل",           "en": "Messages"},
    "cost":           {"ar": "التكلفة",         "en": "Cost"},
    "connected":      {"ar": "متصل",            "en": "Connected"},
    "disconnected":   {"ar": "غير متصل",        "en": "Disconnected"},
    "opt_mode":       {"ar": "وضع التحسين",     "en": "Optimization Mode"},
    "opt_toggle":     {"ar": "تفعيل الوضع المحسَّن", "en": "Enable Optimized Mode"},
    "opt_on":         {"ar": "⚡ وضع محسَّن",   "en": "⚡ Optimized Mode ON"},
    "clear_chat":     {"ar": "🗑️ مسح المحادثة","en": "🗑️ Clear Chat"},
    "logout":         {"ar": "🚪 تسجيل الخروج","en": "🚪 Logout"},
    "type_msg":       {"ar": "اكتب رسالتك هنا...","en": "Type your message here..."},
    "thinking":       {"ar": "كيفة بتفكر...",   "en": "Kayfa is thinking..."},
    "msg_cost":       {"ar": "تكلفة الرسالة",   "en": "Message cost"},
    "optimized":      {"ar": "محسَّن",           "en": "Optimized"},
    "lead_saved":     {"ar": "✅ تم حفظ بيانات العميل", "en": "✅ Customer saved to CRM"},
    "welcome": {
        "ar": "👋 أهلاً! أنا كيفة، مساعد Kayfa الذكي.<br>بساعدك تلاقي أنسب مسار تعليمي يناسب أهدافك.<br><br>إيه اللي بتدور عليه؟ 🎯",
        "en": "👋 Hello! I'm Kayfa, your smart Kayfa Academy assistant.<br>I'll help you find the perfect learning path for your goals.<br><br>What are you looking for? 🎯"
    },
    "crm_title":      {"ar": "CRM Dashboard — Kayfa",         "en": "CRM Dashboard — Kayfa"},
    "crm_subtitle":   {"ar": "جميع الـ Leads المحفوظة",       "en": "All captured leads"},
    "total_leads":    {"ar": "إجمالي الـ Leads",              "en": "Total Leads"},
    "hot":            {"ar": "🔥 ساخن",                       "en": "🔥 Hot"},
    "warm":           {"ar": "🌡️ دافئ",                      "en": "🌡️ Warm"},
    "cold":           {"ar": "❄️ بارد",                       "en": "❄️ Cold"},
    "no_leads":       {"ar": "لا توجد leads بعد",             "en": "No leads yet"},
    "view_conv":      {"ar": "عرض المحادثة الكاملة",          "en": "View Full Conversation"},
    "contact":        {"ar": "التواصل",                       "en": "Contact"},
    "city":           {"ar": "المدينة",                       "en": "City"},
    "product":        {"ar": "المنتج المهتم به",              "en": "Interested In"},
    "level":          {"ar": "المستوى الحالي",                "en": "Current Level"},
    "signals":        {"ar": "إشارات الشراء",                 "en": "Purchase Signals"},
    "objections":     {"ar": "الاعتراضات",                    "en": "Objections"},
    "goal":           {"ar": "الهدف",                         "en": "Goal"},
    "summary":        {"ar": "ملخص المحادثة",                 "en": "Conversation Summary"},
    "next_action":    {"ar": "الإجراء التالي",                "en": "Next Action"},
    "current_user":   {"ar": "المستخدم الحالي",               "en": "Current User"},
    "current_admin":  {"ar": "المسؤول الحالي",                "en": "Current Admin"},
    "admin_title":    {"ar": "Admin Dashboard",               "en": "Admin Dashboard"},
    "admin_subtitle": {"ar": "تكلفة API · تتبع السلوك · التحسين", "en": "API Cost · Behaviour Trace · Optimization"},
    "total_messages": {"ar": "إجمالي الرسائل",                "en": "Total Messages"},
    "total_cost":     {"ar": "إجمالي التكلفة",                "en": "Total Cost"},
    "avg_cost":       {"ar": "متوسط تكلفة الرسالة",           "en": "Avg Cost / Msg"},
    "users":          {"ar": "المستخدمين",                    "en": "Users"},
    "recent_logs":    {"ar": "آخر السجلات",                   "en": "Recent Logs"},
    "no_logs":        {"ar": "لا توجد سجلات بعد",             "en": "No logs yet"},
}


def _get_lang() -> str:
    """Get language from query_params (persists across all pages)."""
    import streamlit as st
    # Read from query params first (persists across page navigation)
    qp = st.query_params.get("lang", None)
    if qp in ("ar", "en"):
        st.session_state["lang"] = qp
        return qp
    # Fall back to session state
    return st.session_state.get("lang", "ar")


def tr(key: str) -> str:
    """Return UI string in current language."""
    lang = _get_lang()
    return UI.get(key, {}).get(lang, key)


def lang_button(location="top"):
    """
    Render language toggle button.
    Uses query_params so language persists across ALL pages.
    """
    import streamlit as st

    lang = _get_lang()
    label = "🌐 English" if lang == "ar" else "🌐 عربي"

    _, col = st.columns([8, 1])
    with col:
        if st.button(label, key=f"lang_btn_{location}", use_container_width=True):
            new_lang = "en" if lang == "ar" else "ar"
            st.session_state["lang"] = new_lang
            st.query_params["lang"] = new_lang  # persists across pages!
            st.rerun()