"""
app_ai.py — Page 1: Chat Agent with Behaviour Trace + Cost Tracking
"""

import os
import uuid
import base64
import streamlit as st
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(override=True)

from knowledge_base import get_kb
from agent import chat
from db import save_ticket, is_connected
from cost_tracker import save_cost_record

# ── Logo ──────────────────────────────────────────────────────────
def get_logo_b64():
    p = Path("assets/logo.png")
    if p.exists():
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode()
    return ""

LOGO = get_logo_b64()

st.set_page_config(
    page_title="Kayfa AI Sales Agent",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Unified logo size in sidebar
if Path("assets/logo.png").exists():
    st.logo("assets/logo.png")

# ── LOGIN ─────────────────────────────────────────────────────────
USERS = {
    os.getenv("LOGIN_USERNAME", "kayfa_admin"): (os.getenv("LOGIN_PASSWORD", "kayfa2026"), "admin"),
    os.getenv("SALES_USERNAME", "sales"):        (os.getenv("SALES_PASSWORD",  "sales2026"), "sales"),
}

def show_login():
    logo_b64 = LOGO if LOGO else ""

    pattern_logos = ""
    if logo_b64:
        positions = [
            "top:-60px;right:-60px;width:320px;opacity:0.055;transform:rotate(15deg);",
            "top:28%;right:-90px;width:280px;opacity:0.045;transform:rotate(-8deg);",
            "bottom:-50px;right:10px;width:250px;opacity:0.05;transform:rotate(22deg);",
            "top:-50px;left:-70px;width:270px;opacity:0.04;transform:rotate(-18deg);",
            "bottom:8%;left:-80px;width:300px;opacity:0.05;transform:rotate(12deg);",
            "bottom:-70px;left:38%;width:220px;opacity:0.035;transform:rotate(5deg);",
        ]
        for pos in positions:
            pattern_logos += f'<img src="data:image/png;base64,{logo_b64}" style="position:absolute;{pos}filter:hue-rotate(210deg) brightness(0.5) saturate(0.7);pointer-events:none;"/>'

    center_logo = f'<img src="data:image/png;base64,{logo_b64}" style="width:90px;height:90px;object-fit:contain;display:block;margin:0 auto 1.1rem;filter:drop-shadow(0 0 18px rgba(99,102,241,0.65)) drop-shadow(0 0 35px rgba(139,92,246,0.35));"/>' if logo_b64 else '<div style="font-size:4rem;text-align:center;margin-bottom:1rem;">🎓</div>'

    st.markdown(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');

    html, body, [class*="css"] {{
        font-family: 'Cairo', sans-serif;
        background: #070b1a !important;
        color: #e2e8f0;
    }}

    section[data-testid="stSidebar"] {{ display: none !important; }}
    [data-testid="collapsedControl"]  {{ display: none !important; }}
    header[data-testid="stHeader"]    {{ display: none !important; }}

    .stApp {{
        background: linear-gradient(135deg, #070b1a 0%, #0d0f2b 50%, #080c1e 100%) !important;
        min-height: 100vh;
        overflow: hidden;
    }}

    section.main .block-container {{
        padding: 0 !important;
        max-width: 100% !important;
    }}

    /* Grid + glow background */
    .login-bg {{
        position: fixed;
        inset: 0;
        overflow: hidden;
        z-index: 0;
    }}
    .login-bg::before {{
        content: '';
        position: absolute;
        inset: 0;
        background-image:
            linear-gradient(rgba(99,102,241,0.055) 1px, transparent 1px),
            linear-gradient(90deg, rgba(99,102,241,0.055) 1px, transparent 1px);
        background-size: 64px 64px;
    }}
    .login-bg::after {{
        content: '';
        position: absolute;
        inset: 0;
        background:
            radial-gradient(ellipse at 85% 50%, rgba(99,102,241,0.14) 0%, transparent 55%),
            radial-gradient(ellipse at 15% 80%, rgba(139,92,246,0.09) 0%, transparent 45%),
            radial-gradient(ellipse at 50% 5%,  rgba(79,70,229,0.07) 0%, transparent 38%);
    }}

    /* Full card — logo + title + form */
    .login-card {{
        position: relative;
        z-index: 10;
        width: 420px;
        margin: 6vh auto 0;
        background: rgba(9, 11, 28, 0.88);
        border: 1px solid rgba(99,102,241,0.28);
        border-radius: 22px;
        padding: 2.8rem 2.4rem 2.4rem;
        text-align: center;
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        box-shadow:
            0 0 0 1px rgba(139,92,246,0.07),
            0 40px 100px rgba(0,0,0,0.65),
            inset 0 1px 0 rgba(255,255,255,0.04);
    }}

    .login-title {{
        font-size: 1.65rem;
        font-weight: 800;
        color: #e2e8f0;
        margin: 0 0 0.2rem;
    }}
    .login-sub {{
        font-size: 0.84rem;
        color: #3d4470;
        margin-bottom: 2rem;
    }}

    /* Inputs — no label */
    div[data-testid="stTextInput"] label {{ display: none !important; }}
    div[data-testid="stTextInput"] div[data-baseweb="input"] {{
        background: rgba(255,255,255,0.03) !important;
        border: 1px solid rgba(99,102,241,0.18) !important;
        border-radius: 11px !important;
    }}
    div[data-testid="stTextInput"] input {{
        background: transparent !important;
        color: #e2e8f0 !important;
        font-size: 0.97rem !important;
        padding: 0.75rem 1rem !important;
        font-family: 'Cairo', sans-serif !important;
        direction: rtl !important;
        text-align: right !important;
    }}
    div[data-testid="stTextInput"] input:focus {{
        border: none !important;
        box-shadow: none !important;
    }}
    div[data-testid="stTextInput"] div[data-baseweb="input"]:focus-within {{
        border-color: rgba(99,102,241,0.55) !important;
        box-shadow: 0 0 0 3px rgba(99,102,241,0.1) !important;
        background: rgba(99,102,241,0.04) !important;
    }}
    div[data-testid="stTextInput"] input::placeholder {{
        color: #2e3460 !important;
    }}

    /* Login button */
    div[data-testid="stFormSubmitButton"] > button {{
        background: linear-gradient(135deg, #4338ca 0%, #6d28d9 100%) !important;
        color: #ffffff !important;
        border: 1px solid rgba(139,92,246,0.4) !important;
        border-radius: 11px !important;
        font-size: 1.05rem !important;
        font-weight: 700 !important;
        padding: 0.78rem !important;
        width: 100% !important;
        margin-top: 0.5rem !important;
        letter-spacing: 0.04em !important;
        box-shadow: 0 4px 22px rgba(99,102,241,0.45), 0 0 40px rgba(99,102,241,0.12) !important;
        font-family: 'Cairo', sans-serif !important;
    }}
    div[data-testid="stFormSubmitButton"] > button:hover {{
        transform: translateY(-1px) !important;
        box-shadow: 0 8px 32px rgba(99,102,241,0.6) !important;
    }}

    div[data-testid="stAlert"] {{ border-radius: 11px !important; margin-top: 0.5rem !important; }}

    /* Hide press enter message */
    div[data-testid="stTextInput"] div[aria-label="Press Enter to submit form"],
    div[data-testid="InputInstructions"],
    [data-testid="InputInstructions"],
    small[data-testid="InputInstructions"] {{ display: none !important; }}
    div[data-testid="stTextInput"] > div > div > div:last-child:not(input) {{ display: none !important; }}
    .st-emotion-cache-eczf16 {{ display: none !important; }}
    span[style*="Press Enter"] {{ display: none !important; }}

    /* Hide column padding */
    [data-testid="stHorizontalBlock"] {{ gap: 0 !important; }}
    [data-testid="stColumn"] {{ background: transparent !important; padding: 0 !important; }}

    /* Corner star */
    .corner-star {{
        position: fixed;
        bottom: 2.5rem; right: 3rem;
        z-index: 5;
        width: 36px; height: 36px;
        background: linear-gradient(135deg, #4338ca, #6d28d9);
        clip-path: polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);
        filter: drop-shadow(0 0 14px rgba(99,102,241,0.8));
        opacity: 0.75;
    }}
    </style>

    <div class="login-bg">{pattern_logos}</div>
    <div class="corner-star"></div>
    <div class="login-card">
        {center_logo}
        <div class="login-title">Sign In</div>
        <div class="login-sub">Kayfa AI Sales Agent Portal</div>
    </div>
    """, unsafe_allow_html=True)

    # Form column — appears directly below the card
    col_l, col_m, col_r = st.columns([1, 1.5, 1])
    with col_m:
        st.markdown('<div style="margin-top:-1.5rem;">', unsafe_allow_html=True)
        with st.form("login_form", clear_on_submit=False):
            username  = st.text_input("u", placeholder="Username",  label_visibility="collapsed")
            password  = st.text_input("p", placeholder="Password", type="password", label_visibility="collapsed")
            submitted = st.form_submit_button("Sign In", use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)

        if submitted:
            user = USERS.get(username)
            if user and user[0] == password:
                st.session_state["authenticated"]   = True
                st.session_state["role"]            = user[1]
                st.session_state["username"]        = username
                st.session_state["conversation_id"] = str(uuid.uuid4())
                st.rerun()
            else:
                st.error("❌ Wrong username or password")

if not st.session_state.get("authenticated"):
    show_login()
    st.stop()

# ── Language & Theme init (early — needed before CSS) ────────────────────────
if "lang"      not in st.session_state: st.session_state.lang      = "ar"
if "dark_mode" not in st.session_state: st.session_state.dark_mode = True

def t(ar, en):
    return en if st.session_state.get("lang") == "en" else ar

# ── CSS — Dark / Light Mode ───────────────────────────────────────────────────
_dm = st.session_state.get("dark_mode", True)

# Dark theme colors
_bg        = "#06050f"       if _dm else "#f4f3ff"
_bg2       = "#0c0a1e"       if _dm else "#ebe9ff"
_sidebar   = "rgba(10,8,28,0.97)"  if _dm else "rgba(245,243,255,0.98)"
_sb_border = "rgba(139,92,246,0.25)" if _dm else "rgba(139,92,246,0.2)"
_sb_text   = "#c4b5fd"       if _dm else "#4c1d95"
_sb_strong = "#ede9fe"       if _dm else "#2e1065"
_text      = "#e2e8f0"       if _dm else "#1e1b4b"
_hdr_bg    = "linear-gradient(135deg,rgba(88,28,135,0.35),rgba(15,10,40,0.97))" if _dm else "linear-gradient(135deg,rgba(237,233,254,0.9),rgba(221,214,254,0.95))"
_hdr_h1    = "#c084fc"       if _dm else "#5b21b6"
_hdr_p     = "#a78bfa"       if _dm else "#7c3aed"
_hdr_brd   = "rgba(139,92,246,0.3)"  if _dm else "rgba(139,92,246,0.25)"
_chat_bg   = "rgba(10,8,26,0.97)"    if _dm else "rgba(255,255,255,0.95)"
_chat_brd  = "rgba(139,92,246,0.12)" if _dm else "rgba(139,92,246,0.15)"
_msg_user_bg = "linear-gradient(135deg,rgba(88,28,135,0.5),rgba(109,40,217,0.4))" if _dm else "linear-gradient(135deg,rgba(167,139,250,0.25),rgba(139,92,246,0.2))"
_msg_user_c  = "#ede9fe"     if _dm else "#2e1065"
_msg_ai_bg   = "rgba(12,10,30,0.95)" if _dm else "rgba(245,243,255,0.9)"
_msg_ai_c    = "#ddd6fe"     if _dm else "#1e1b4b"
_input_bg    = "rgba(12,10,30,0.95)" if _dm else "#ffffff"
_bottom_bg   = "#06050f"     if _dm else "#f4f3ff"
_expander_bg = "rgba(12,10,30,0.95)" if _dm else "rgba(245,243,255,0.95)"
_metric_c    = "#a78bfa"     if _dm else "#5b21b6"
_gr1 = "rgba(139,92,246,0.13)" if _dm else "rgba(139,92,246,0.06)"
_gr2 = "rgba(99,102,241,0.10)" if _dm else "rgba(99,102,241,0.05)"
_gr3 = "rgba(168,85,247,0.07)" if _dm else "rgba(168,85,247,0.03)"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');
html, body, [class*="css"] {{ font-family: 'Cairo', sans-serif; color: {_text}; background: {_bg} !important; }}

.stApp {{
    background:
        radial-gradient(ellipse at 15% 15%, {_gr1} 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, {_gr2} 0%, transparent 45%),
        radial-gradient(ellipse at 50% 0%,  {_gr3} 0%, transparent 40%),
        linear-gradient(180deg, {_bg} 0%, {_bg2} 100%) !important;
}}

section[data-testid="stSidebar"] {{
    background: {_sidebar} !important;
    border-right: 1px solid {_sb_border} !important;
}}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div,
section[data-testid="stSidebar"] label {{ color: {_sb_text} !important; }}
section[data-testid="stSidebar"] strong {{ color: {_sb_strong} !important; }}
section[data-testid="stSidebar"] hr     {{ border-color: {_sb_border} !important; }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] {{ border-radius:10px !important; color:{_sb_text} !important; }}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"]:hover {{ background:rgba(139,92,246,0.15) !important; }}
section[data-testid="stSidebar"] [aria-selected="true"] {{ background:rgba(139,92,246,0.2) !important; }}
section[data-testid="stSidebar"] .stButton > button {{
    background: linear-gradient(135deg,#6d28d9,#7c3aed) !important;
    color: #fff !important; border: none !important;
    border-radius: 12px !important; font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(139,92,246,0.3) !important;
}}

[data-testid="stSidebarHeader"] {{
    padding:1.1rem 1rem 0.8rem !important;
    border-bottom:1px solid {_sb_border} !important;
    margin-bottom:0.4rem !important;
}}
[data-testid="stLogo"] img,
[data-testid="stSidebarHeader"] img {{
    width:48px !important; height:48px !important;
    max-width:48px !important; max-height:48px !important;
    min-width:48px !important; min-height:48px !important;
    object-fit:contain !important; display:block !important;
    margin:0 auto !important; transform:none !important;
    filter:drop-shadow(0 3px 12px rgba(139,92,246,0.4)) !important;
}}

.kayfa-header {{
    background: {_hdr_bg};
    padding:1.6rem 2rem; border-radius:24px; margin-bottom:1.5rem;
    border:1px solid {_hdr_brd};
    box-shadow:0 0 0 1px rgba(139,92,246,0.1),0 28px 70px rgba(0,0,0,0.2);
    display:flex; align-items:center; gap:1rem;
}}
.kayfa-header h1 {{ color:{_hdr_h1}; margin:0; font-size:1.9rem; font-weight:800; }}
.kayfa-header p  {{ color:{_hdr_p};  margin:0.5rem 0 0; font-size:1rem; }}

div[data-testid="stBottom"] {{ background:{_bottom_bg} !important; border-top:1px solid rgba(139,92,246,0.15) !important; }}
div[data-testid="stChatInput"] {{ background:{_input_bg} !important; border:1px solid rgba(139,92,246,0.25) !important; border-radius:16px !important; }}
div[data-testid="stChatInput"] textarea {{ background:{_input_bg} !important; color:{_text} !important; }}

.chat-wrap {{
    background:{_chat_bg}; border:1px solid {_chat_brd};
    border-radius:24px; padding:1.35rem; margin-bottom:1.4rem;
}}
.msg-user {{
    padding:1rem 1.1rem; border-radius:24px; margin:0.5rem 0;
    line-height:1.6; max-width:82%; margin-left:auto;
    background:{_msg_user_bg};
    color:{_msg_user_c}; border:1px solid rgba(139,92,246,0.25);
    direction:rtl; text-align:right;
    box-shadow:0 8px 25px rgba(139,92,246,0.15);
}}
.msg-assistant {{
    padding:1rem 1.1rem; border-radius:24px; margin:0.5rem 0;
    line-height:1.6; max-width:82%;
    background:{_msg_ai_bg};
    color:{_msg_ai_c}; border:1px solid rgba(139,92,246,0.15);
    direction:rtl; text-align:right;
    box-shadow:0 8px 25px rgba(0,0,0,0.1);
}}
.msg-assistant-en {{
    padding:1rem 1.1rem; border-radius:24px; margin:0.5rem 0;
    line-height:1.6; max-width:82%;
    background:{_msg_ai_bg};
    color:{_msg_ai_c}; border:1px solid rgba(139,92,246,0.15);
    direction:ltr; text-align:left;
    box-shadow:0 8px 25px rgba(0,0,0,0.1);
}}
.cost-pill {{
    display:inline-flex; align-items:center; gap:0.35rem;
    background:rgba(139,92,246,0.1); color:#a78bfa;
    padding:0.4rem 0.8rem; border-radius:999px;
    border:1px solid rgba(139,92,246,0.2); font-size:0.82rem; margin-top:0.4rem;
}}
.lead-badge {{
    display:inline-flex; align-items:center; gap:0.35rem;
    background:rgba(16,185,129,0.12); color:#a7f3d0;
    padding:0.55rem 0.95rem; border-radius:999px;
    border:1px solid rgba(16,185,129,0.2); font-size:0.92rem;
}}
.opt-badge {{
    display:inline-flex; align-items:center; gap:0.35rem;
    background:rgba(139,92,246,0.15); color:#c4b5fd;
    padding:0.4rem 0.8rem; border-radius:999px;
    border:1px solid rgba(139,92,246,0.25); font-size:0.82rem;
}}
[data-testid="stMetricValue"] {{ color:{_metric_c} !important; font-weight:700 !important; }}
hr {{ border-color:rgba(139,92,246,0.15) !important; }}
[data-testid="stExpander"] {{
    background:{_expander_bg} !important;
    border:1px solid rgba(139,92,246,0.2) !important;
    border-radius:14px !important;
}}
[data-testid="stHorizontalBlock"] {{ gap:1rem !important; }}
[data-testid="stColumn"] {{ background:transparent !important; padding:0 !important; }}
</style>
""", unsafe_allow_html=True)

st.markdown(f"""
<div class="kayfa-header">
    {'<img src="data:image/png;base64,' + LOGO + '" style="width:46px;height:46px;object-fit:contain;border-radius:10px;"/>' if LOGO else '🎓'}
    <div>
        <h1>Kayfa AI Sales Agent</h1>
        <p>{"Smart Sales Agent — Cost & Behaviour Tracking"}</p>
    </div>
</div>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner="⏳ Loading knowledge base...")
def load_resources():
    chunks, index = get_kb()
    return chunks, index

chunks, index = load_resources()

# ── Session init ──────────────────────────────────────────────────────────────
if "messages"       not in st.session_state: st.session_state.messages       = []
if "leads_saved"    not in st.session_state: st.session_state.leads_saved    = []
if "total_cost"     not in st.session_state: st.session_state.total_cost     = 0.0
if "msg_count"      not in st.session_state: st.session_state.msg_count      = 0
if "last_trace"     not in st.session_state: st.session_state.last_trace     = []
if "last_cost"      not in st.session_state: st.session_state.last_cost      = {}
if "conversation_id" not in st.session_state: st.session_state.conversation_id = str(uuid.uuid4())
if "optimized_mode" not in st.session_state: st.session_state.optimized_mode = False

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    role  = st.session_state.get("sales", "")
    uname = st.session_state.get("username", "")
    db_ok = is_connected()

    st.markdown(f"""
<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);
    border-radius:14px;padding:0.9rem 1rem;margin-bottom:0.8rem;">
    <div style="color:#c4b5fd;font-size:0.82rem;margin-bottom:0.5rem;">{"Current Session"}</div>
    <div style="display:flex;flex-direction:column;gap:0.35rem;">
        <span>👤 <strong>{uname}</strong> — {'🔴 Admin' if role=='admin' else '🟡 Sales'}</span>
        <span>🗄️ MongoDB: {'🟢 ' + "Connected" if db_ok else '🔴 ' + "Disconnected"}</span>
        <span>💬 {"Messages"}: <strong>{st.session_state.msg_count}</strong></span>
        <span>🎯 Leads: <strong>{len(st.session_state.leads_saved)}</strong></span>
        <span>💵 {"Cost"}: <strong style="color:#34d399;">${st.session_state.total_cost:.5f}</strong></span>
    </div>
</div>
""", unsafe_allow_html=True)

    st.markdown("---")

    # ── Language Toggle ───────────────────────────────────────────

    # ── Dark / Light Mode ─────────────────────────────────────────
    dark_mode = st.toggle(
        "🌙 Dark Mode",
        value=st.session_state.dark_mode,
        key="dark_toggle",
    )
    if dark_mode != st.session_state.dark_mode:
        st.session_state.dark_mode = dark_mode
        st.rerun()

    st.markdown("---")

    # ── Optimization ──────────────────────────────────────────────
    st.markdown(f"#### ⚡ {"Optimization Mode"}")
    optimized = st.toggle(
        "Enable Optimized Mode (cheaper)",
        value=st.session_state.optimized_mode,
        help="Uses a cheaper model & shorter prompt — ~96% cost saving"
    )
    if optimized != st.session_state.optimized_mode:
        st.session_state.optimized_mode = optimized
        st.rerun()

    if st.session_state.optimized_mode:
        st.markdown(f'<div class="opt-badge">⚡ {"Optimized Mode ON"}</div>',
                    unsafe_allow_html=True)

    st.markdown("---")
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages        = []
        st.session_state.total_cost      = 0.0
        st.session_state.msg_count       = 0
        st.session_state.conversation_id = str(uuid.uuid4())
        st.rerun()

    if st.button("🚪 Logout", use_container_width=True):
        for k in ["authenticated", "role", "username"]:
            st.session_state[k] = None
        st.rerun()

# ── Chat display ──────────────────────────────────────────────────────────────
st.markdown('<div class="chat-wrap">', unsafe_allow_html=True)
for msg in st.session_state.messages:
    ar_chars = sum(1 for c in msg["content"] if '\u0600' <= c <= '\u06ff')
    if msg["role"] == "user":
        role_class = "msg-user"
    elif ar_chars >= 5:
        role_class = "msg-assistant"
    else:
        role_class = "msg-assistant-en"
    st.markdown(f'<div class="{role_class}">{msg["content"]}</div>', unsafe_allow_html=True)

if not st.session_state.messages:
    st.markdown('''
    <div class="msg-assistant-en">
    👋 Hello! I\'m Kayfa, your smart Kayfa Academy assistant.<br>
    I\'ll help you find the perfect learning path for your goals.<br><br>
    What are you looking for? 🎯
    </div>
    ''', unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

# ── Chat input ────────────────────────────────────────────────────────────────
user_input = st.chat_input("Type your message here...")

if user_input:
    st.markdown(f'<div class="msg-user">{user_input}</div>', unsafe_allow_html=True)

    with st.spinner("Kayfa is thinking..."):
        reply, lead_data, trace, cost_info = chat(
            st.session_state.messages,
            user_input,
            chunks, index,
            embedder=None,
            optimized=st.session_state.optimized_mode,
            conversation_id=st.session_state.conversation_id,
        )

    # Show reply
    ar_chars = sum(1 for c in reply if '\u0600' <= c <= '\u06ff')
    reply_class = "msg-assistant" if ar_chars >= 5 else "msg-assistant-en"
    st.markdown(f'<div class="{reply_class}">{reply}</div>', unsafe_allow_html=True)

    # Show message cost
    cost_badge = f"💵 ${cost_info['total_cost']:.6f} | ⏱ {cost_info.get('elapsed_s',0)}s"
    if st.session_state.optimized_mode:
        cost_badge += " | ⚡ " + "Optimized"
    st.markdown(f'<div class="cost-pill">📊 {"Message cost"}: {cost_badge}</div>', unsafe_allow_html=True)

    # Update session
    st.session_state.messages.append({"role": "user",      "content": user_input})
    st.session_state.messages.append({"role": "assistant", "content": reply})
    st.session_state.total_cost += cost_info["total_cost"]
    st.session_state.msg_count  += 1
    st.session_state.last_trace  = trace
    st.session_state.last_cost   = cost_info

    # حفظ تكلفة في MongoDB
    save_cost_record(
        user_id=st.session_state.get("unknown", ""),
        conversation_id=st.session_state.conversation_id,
        model=cost_info["model"],
        input_tokens=cost_info["input_tokens"],
        output_tokens=cost_info["output_tokens"],
        optimized=st.session_state.optimized_mode,
        trace_steps=trace,
    )

    # حفظ Lead
    if lead_data and lead_data.get("الاسم"):
        lead_data["conversation"] = st.session_state.messages.copy()
        try:
            ticket_id = save_ticket(lead_data)
            st.session_state.leads_saved.append(ticket_id)
            st.markdown('<div class="lead-badge">✅ تم حفظ بيانات العميل في نظام CRM</div>',
                        unsafe_allow_html=True)
        except Exception as e:
            st.warning(f"تعذر حفظ الـ CRM ticket: {e}")

    # Trace محفوظ في session للـ Admin Dashboard (مش بيظهر هنا)
    pass