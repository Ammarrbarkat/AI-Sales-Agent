import os
from dotenv import load_dotenv
from twilio.rest import Client

load_dotenv(override=True)

ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
FROM_NUMBER = os.getenv("TWILIO_WHATSAPP_NUMBER")


def send_whatsapp_message(student_name, course_name, to_number):

    if not ACCOUNT_SID or not AUTH_TOKEN or not FROM_NUMBER:
        print("Twilio credentials missing")
        return False

    try:
        client = Client(ACCOUNT_SID, AUTH_TOKEN)

        body = f"""
مرحبًا {student_name} 👋

تم استلام طلبك بخصوص {course_name} ✅

أحد أعضاء فريقنا سيتواصل معك قريبًا.

شكرًا لاهتمامك 🙏
"""

        client.messages.create(
            from_=f"whatsapp:{FROM_NUMBER}",
            body=body,
            to=f"whatsapp:{to_number}"
        )

        print("WhatsApp sent successfully")
        return True

    except Exception as e:
        print(f"WhatsApp Error: {e}")
        return False