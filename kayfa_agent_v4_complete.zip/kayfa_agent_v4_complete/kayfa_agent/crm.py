"""
Kayfa CRM — saves and retrieves leads from MongoDB.
"""

import os
import datetime
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv(override=True)

# Note: uses MONGODB_URI (same as db.py) not MONGO_URI
MONGO_URI = os.environ.get("MONGODB_URI", os.environ.get("MONGO_URI", "mongodb://localhost:27017"))
DB_NAME   = "kayfa_crm"
COL_NAME  = "leads"


def _get_collection():
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    return client[DB_NAME][COL_NAME]


def save_lead(lead: dict) -> str:
    """Save a lead dict to MongoDB. Returns inserted id as string."""
    lead["timestamp"] = datetime.datetime.utcnow().isoformat()
    col = _get_collection()
    result = col.insert_one(lead)
    return str(result.inserted_id)


def get_all_leads() -> list[dict]:
    """Return all leads sorted by newest first."""
    col = _get_collection()
    leads = list(col.find({}, {"_id": 0}).sort("timestamp", -1))
    return leads


def build_crm_ticket(
    name: str,
    phone: str,
    city: str,
    language: str,
    interests: str,
    goal: str,
    level: str,
    temperature: str,
    objections: str,
    summary: str,
    next_action: str,
) -> dict:
    """Build a structured CRM ticket (in Arabic)."""
    return {
        "full_name": name,
        "phone": phone,
        "city": city,
        "language": language,
        "interests": interests,
        "goal": goal,
        "current_level": level,
        "interest_temperature": temperature,       
        "objections": objections,
        "summary": summary,
        "next_action": next_action,
    }
