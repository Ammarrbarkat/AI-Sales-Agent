"""
pages/crm_dashboard.py — CRM Dashboard (Sales view) — Purple Theme موحد
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
from pathlib import Path
from crm import get_all_leads

st.set_page_config(page_title="Kayfa — CRM Tickets", page_icon="📋", layout="wide")

if Path("assets/logo.png").exists():
    st.logo("assets/logo.png")

if not st.session_state.get("authenticated"):
    st.error("🔒 يرجى تسجيل الدخول أولاً من الصفحة الرئيسية")
    st.stop()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Cairo', sans-serif; color: #e2e8f0; background: #06050f !important; }

.stApp {
    background:
        radial-gradient(ellipse at 15% 15%, rgba(139,92,246,0.13) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, rgba(99,102,241,0.10) 0%, transparent 45%),
        radial-gradient(ellipse at 50% 0%,  rgba(168,85,247,0.07) 0%, transparent 40%),
        linear-gradient(180deg, #06050f 0%, #0c0a1e 100%) !important;
}
section.main .block-container { padding-top: 0.75rem !important; background: transparent !important; }
section.main, div[data-testid="stMain"] { background: transparent !important; }

section[data-testid="stSidebar"] {
    background: rgba(10, 8, 28, 0.97) !important;
    border-right: 1px solid rgba(139,92,246,0.25) !important;
}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div,
section[data-testid="stSidebar"] label { color: #c4b5fd !important; }
section[data-testid="stSidebar"] strong { color: #ede9fe !important; }
section[data-testid="stSidebar"] hr     { border-color: rgba(139,92,246,0.2) !important; }
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] { border-radius: 10px !important; color: #c4b5fd !important; }
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"]:hover { background: rgba(139,92,246,0.15) !important; }
section[data-testid="stSidebar"] [aria-selected="true"] { background: rgba(139,92,246,0.2) !important; }

[data-testid="stSidebarHeader"] {
    padding: 1.1rem 1rem 0.8rem !important;
    border-bottom: 1px solid rgba(139,92,246,0.2) !important;
    margin-bottom: 0.4rem !important;
}
[data-testid="stLogo"] img,
[data-testid="stSidebarHeader"] img {
    width: 48px !important; height: 48px !important;
    max-width: 48px !important; max-height: 48px !important;
    min-width: 48px !important; min-height: 48px !important;
    object-fit: contain !important; display: block !important;
    margin: 0 auto !important; transform: none !important;
    filter: drop-shadow(0 3px 12px rgba(139,92,246,0.4)) !important;
}

.page-header {
    background: linear-gradient(135deg, rgba(88,28,135,0.35) 0%, rgba(15,10,40,0.97) 60%);
    padding: 1.6rem 2rem; border-radius: 24px; margin-bottom: 1.6rem;
    border: 1px solid rgba(139,92,246,0.3);
    box-shadow: 0 0 0 1px rgba(139,92,246,0.1), 0 24px 60px rgba(0,0,0,0.4);
}
.page-header h1 { color: #c084fc; margin: 0; font-size: 1.85rem; font-weight: 800; }
.page-header p  { color: #a78bfa; margin: 0.3rem 0 0; font-size: 0.97rem; }

.kpi-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 20px; padding: 1.3rem 1rem;
    text-align: center; margin-bottom: 1rem;
    transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card:hover { transform: translateY(-2px); box-shadow: 0 12px 40px rgba(139,92,246,0.2); }
.kpi-card .kpi-val       { font-size: 2rem; font-weight: 800; }
.kpi-card .kpi-val.count { color: #a78bfa; }
.kpi-card .kpi-label     { color: #7c6ea8; font-size: 0.88rem; margin-top: 0.25rem; }

.ticket-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 22px; padding: 1.4rem 1.6rem;
    margin-bottom: 1.2rem; direction: rtl; text-align: right;
    box-shadow: 0 18px 45px rgba(0,0,0,0.25);
    transition: transform 0.2s, box-shadow 0.2s;
}
.ticket-card:hover { transform: translateY(-2px); box-shadow: 0 24px 60px rgba(139,92,246,0.15); }
.ticket-card.hot  { border-left: 4px solid #c084fc; }
.ticket-card.warm { border-left: 4px solid #a78bfa; }
.ticket-card.cold { border-left: 4px solid #818cf8; }

.badge-hot  { background: linear-gradient(135deg,#7c3aed,#9333ea); color:#fff; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-warm { background: linear-gradient(135deg,#6d28d9,#7c3aed); color:#ddd6fe; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-cold { background: rgba(99,102,241,0.2); color:#a5b4fc; padding:5px 14px; border-radius:999px; font-size:0.82rem; border:1px solid rgba(99,102,241,0.3); }

.field-label { color: #7c6ea8; font-size: 0.85rem; }
.field-value { color: #e2e8f0; font-weight: 600; }
.field-name  { color: #c084fc; font-size: 1.1rem; font-weight: 800; }
.action-box {
    background: rgba(139,92,246,0.08); border: 1px solid rgba(139,92,246,0.2);
    border-radius: 12px; padding: 0.7rem 1rem; margin-top: 0.8rem;
}

/* ── إصلاح خلفية الـ columns ── */
[data-testid="stHorizontalBlock"] { gap: 1rem !important; }
[data-testid="stColumn"] { background: transparent !important; padding: 0 !important; }
[data-testid="stVerticalBlock"] { background: transparent !important; }
div.stColumn > div { background: transparent !important; }

section[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #6d28d9, #7c3aed) !important;
    color: #fff !important; border: none !important;
    border-radius: 12px !important; font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(139,92,246,0.3) !important;
}

[data-testid="stMetricValue"] { color: #a78bfa !important; font-weight: 700 !important; }
hr { border-color: rgba(139,92,246,0.15) !important; }
[data-testid="stExpander"] {
    background: rgba(12,10,30,0.95) !important;
    border: 1px solid rgba(139,92,246,0.2) !important;
    border-radius: 14px !important;
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="page-header">
    <h1>📋 CRM Tickets — لوحة تحكم المبيعات</h1>
    <p>كل الـ leads اللي اتجمعت من الـ AI Sales Agent</p>
</div>
""", unsafe_allow_html=True)

try:
    leads = get_all_leads()
except Exception as e:
    st.error(f"خطأ في الاتصال بـ MongoDB: {e}")
    leads = []

total = len(leads)
hot   = sum(1 for l in leads if "ساخن" in str(l.get("درجة_الاهتمام", "") or l.get("حرارة_العميل", "")))
warm  = sum(1 for l in leads if "دافئ" in str(l.get("درجة_الاهتمام", "") or l.get("حرارة_العميل", "")))
cold  = total - hot - warm

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{total}</div><div class="kpi-label">📊 إجمالي الـ Leads</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{hot}</div><div class="kpi-label">🔥 ساخن</div></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{warm}</div><div class="kpi-label">🌡️ دافئ</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{cold}</div><div class="kpi-label">❄️ بارد</div></div>', unsafe_allow_html=True)

st.markdown('<hr style="margin:1.2rem 0;"/>', unsafe_allow_html=True)

if not leads:
    st.info("📭 مفيش leads لحد دلوقتي. ابدأ محادثة من الصفحة الرئيسية!")
    st.stop()

for lead in leads:
    temp = str(lead.get("درجة_الاهتمام", "") or lead.get("حرارة_العميل", ""))
    card_class  = "hot" if "ساخن" in temp else ("warm" if "دافئ" in temp else "cold")
    badge_class = f"badge-{card_class}"
    badge_text  = "🔥 ساخن" if card_class=="hot" else ("🌡️ دافئ" if card_class=="warm" else "❄️ بارد")

    name      = lead.get("الاسم", "—")
    phone     = lead.get("رقم_التواصل", lead.get("التواصل", "—"))
    city      = lead.get("المدينة", "—")
    interest  = lead.get("المنتجات_محل_الاهتمام", lead.get("المنتج_المهتم_به", "—"))
    goal      = lead.get("الهدف", "—")
    level     = lead.get("المستوى_الحالي", "—")
    objection = lead.get("الاعتراضات", "—")
    summary   = lead.get("ملخص_المحادثة", "—")
    action    = lead.get("الإجراء_التالي", "—")
    timestamp = lead.get("timestamp", lead.get("created_at", "—"))
    ts_str    = timestamp[:16] if timestamp and timestamp != "—" else "—"

    st.markdown(f"""
<div class="ticket-card {card_class}">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <span class="field-name">👤 {name}</span>
        <div style="display:flex;gap:0.6rem;align-items:center;">
            <span class="{badge_class}">{badge_text}</span>
            <span style="color:#4a4070;font-size:0.78rem;">{ts_str}</span>
        </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.7rem;margin-bottom:0.7rem;">
        <div><div class="field-label">📞 التواصل</div><div class="field-value">{phone}</div></div>
        <div><div class="field-label">📍 المدينة</div><div class="field-value">{city}</div></div>
        <div><div class="field-label">🎯 المنتج المهتم به</div><div class="field-value">{interest}</div></div>
        <div><div class="field-label">📚 المستوى الحالي</div><div class="field-value">{level}</div></div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">🏁 الهدف</div><div class="field-value">{goal}</div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">⚠️ الاعتراضات</div><div class="field-value">{objection}</div>
    </div>
    <div style="margin-bottom:0.4rem;">
        <div class="field-label">💬 ملخص المحادثة</div><div class="field-value">{summary}</div>
    </div>
    <div class="action-box">
        <div class="field-label">👉 الإجراء التالي</div>
        <div class="field-value" style="color:#34d399;">{action}</div>
    </div>
</div>
""", unsafe_allow_html=True)