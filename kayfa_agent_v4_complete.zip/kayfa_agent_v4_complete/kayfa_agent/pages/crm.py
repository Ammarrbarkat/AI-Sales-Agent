"""
pages/crm.py — CRM Tickets — Purple Theme موحد
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
from pathlib import Path
from db import get_all_tickets, is_connected

# دالة الترجمة المحلية
def t(ar, en):
    return en if st.session_state.get("lang") == "en" else ar

st.set_page_config(page_title="Kayfa CRM", page_icon="📋", layout="wide")

if Path("assets/logo.png").exists():
    st.logo("assets/logo.png")

if not st.session_state.get("authenticated"):
    st.error("🔒 يرجى تسجيل الدخول أولاً من الصفحة الرئيسية")
    st.stop()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Cairo', sans-serif; color: #e2e8f0; background: #06050f !important; }

.stApp {
    background:
        radial-gradient(ellipse at 15% 15%, rgba(139,92,246,0.13) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, rgba(99,102,241,0.10) 0%, transparent 45%),
        radial-gradient(ellipse at 50% 0%,  rgba(168,85,247,0.07) 0%, transparent 40%),
        linear-gradient(180deg, #06050f 0%, #0c0a1e 100%) !important;
}
section.main .block-container { padding-top: 0.75rem !important; background: transparent !important; }
section.main, div[data-testid="stMain"] { background: transparent !important; }

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
    background: rgba(10, 8, 28, 0.97) !important;
    border-right: 1px solid rgba(139,92,246,0.25) !important;
}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div,
section[data-testid="stSidebar"] label { color: #c4b5fd !important; }
section[data-testid="stSidebar"] strong { color: #ede9fe !important; }
section[data-testid="stSidebar"] hr     { border-color: rgba(139,92,246,0.2) !important; }
section[data-testid="stSidebar"] a      { color: #a78bfa !important; }
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] {
    border-radius: 10px !important; color: #c4b5fd !important;
}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"]:hover {
    background: rgba(139,92,246,0.15) !important;
}
section[data-testid="stSidebar"] [aria-selected="true"] {
    background: rgba(139,92,246,0.2) !important; color: #ede9fe !important;
}

/* ── Logo موحد 48px ── */
[data-testid="stSidebarHeader"] {
    padding: 1.1rem 1rem 0.8rem !important;
    border-bottom: 1px solid rgba(139,92,246,0.2) !important;
    margin-bottom: 0.4rem !important;
}
[data-testid="stLogo"] img,
[data-testid="stSidebarHeader"] img {
    width: 48px !important; height: 48px !important;
    max-width: 48px !important; max-height: 48px !important;
    min-width: 48px !important; min-height: 48px !important;
    object-fit: contain !important; display: block !important;
    margin: 0 auto !important; transform: none !important;
    filter: drop-shadow(0 3px 12px rgba(139,92,246,0.4)) !important;
}

/* ── Header ── */
.page-header {
    background: linear-gradient(135deg, rgba(88,28,135,0.35) 0%, rgba(15,10,40,0.97) 60%);
    padding: 1.6rem 2rem; border-radius: 24px; margin-bottom: 1.6rem;
    border: 1px solid rgba(139,92,246,0.3);
    box-shadow: 0 0 0 1px rgba(139,92,246,0.1), 0 24px 60px rgba(0,0,0,0.4);
}
.page-header h1 { color: #c084fc; margin: 0; font-size: 1.85rem; font-weight: 800; }
.page-header p  { color: #a78bfa; margin: 0.3rem 0 0; font-size: 0.97rem; }

/* ── KPI cards ── */
.kpi-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 20px; padding: 1.3rem 1rem;
    text-align: center; margin-bottom: 1rem;
    transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card:hover { transform: translateY(-2px); box-shadow: 0 12px 40px rgba(139,92,246,0.2); }
.kpi-card .kpi-val       { font-size: 2rem; font-weight: 800; }
.kpi-card .kpi-val.money { color: #34d399; }
.kpi-card .kpi-val.count { color: #a78bfa; }
.kpi-card .kpi-label     { color: #7c6ea8; font-size: 0.88rem; margin-top: 0.25rem; }

/* ── Ticket cards ── */
.ticket-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 22px; padding: 1.4rem 1.6rem;
    margin-bottom: 1.2rem; direction: rtl; text-align: right;
    box-shadow: 0 18px 45px rgba(0,0,0,0.25);
    transition: transform 0.2s, box-shadow 0.2s;
}
.ticket-card:hover { transform: translateY(-2px); box-shadow: 0 24px 60px rgba(139,92,246,0.15); }
.ticket-card.hot  { border-left: 4px solid #c084fc; }
.ticket-card.warm { border-left: 4px solid #a78bfa; }
.ticket-card.cold { border-left: 4px solid #818cf8; }

.badge-hot  { background: linear-gradient(135deg,#7c3aed,#9333ea); color:#fff; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-warm { background: linear-gradient(135deg,#6d28d9,#7c3aed); color:#ddd6fe; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-cold { background: rgba(99,102,241,0.2); color:#a5b4fc; padding:5px 14px; border-radius:999px; font-size:0.82rem; border:1px solid rgba(99,102,241,0.3); }

.field-label { color: #7c6ea8; font-size: 0.85rem; }
.field-value { color: #e2e8f0; font-weight: 600; }
.field-name  { color: #c084fc; font-size: 1.1rem; font-weight: 800; }

.action-box {
    background: rgba(139,92,246,0.08); border: 1px solid rgba(139,92,246,0.2);
    border-radius: 12px; padding: 0.7rem 1rem; margin-top: 0.8rem;
}

/* ── إصلاح خلفية الـ columns ── */
[data-testid="stHorizontalBlock"] { gap: 1rem !important; }
[data-testid="stColumn"] { background: transparent !important; padding: 0 !important; }
[data-testid="stVerticalBlock"] { background: transparent !important; }
div.stColumn > div { background: transparent !important; }

/* Buttons */
section[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #6d28d9, #7c3aed) !important;
    color: #fff !important; border: none !important;
    border-radius: 12px !important; font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(139,92,246,0.3) !important;
}

/* Metrics بنفسجي */
[data-testid="stMetricValue"] { color: #a78bfa !important; font-weight: 700 !important; }
[data-testid="stMetricDelta"] { color: #34d399 !important; }
hr { border-color: rgba(139,92,246,0.15) !important; }

/* Expander */
[data-testid="stExpander"] {
    background: rgba(12,10,30,0.95) !important;
    border: 1px solid rgba(139,92,246,0.2) !important;
    border-radius: 14px !important;
}
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    uname = st.session_state.get("username", "")
    role  = st.session_state.get("role", "sales")
    st.markdown(f"""
<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);
    border-radius:14px;padding:0.9rem 1rem;margin-bottom:0.8rem;">
    <div style="color:#c4b5fd;font-size:0.82rem;margin-bottom:0.5rem;">المستخدم الحالي</div>
    <span style="color:#ede9fe;">👤 <strong>{uname}</strong></span><br>
    <span style="font-size:0.85rem;color:#a78bfa;">{'🔴 Admin' if role=='admin' else '🟡 Sales'}</span>
</div>
""", unsafe_allow_html=True)
    if st.button("🚪 Logout", use_container_width=True, key="crm_logout"):
        for k in ["authenticated", "role", "username"]:
            st.session_state[k] = None
        st.switch_page("app_ai.py")
st.markdown("""
<div class="page-header">
    <h1>📋 لوحة تحكم CRM — Kayfa</h1>
    <p>جميع الـ leads المحفوظة من محادثات الـ AI Sales Agent</p>
</div>
""", unsafe_allow_html=True)

if not is_connected():
    st.error("🔴 تعذر الاتصال بـ MongoDB. تأكد من إعداد MONGODB_URI.")
    st.stop()

tickets = get_all_tickets()

# ── KPI Stats ─────────────────────────────────────────────────────────────────
hot  = sum(1 for t in tickets if "ساخن" in str(t.get("حرارة_العميل", "")))
warm = sum(1 for t in tickets if "دافئ" in str(t.get("حرارة_العميل", "")))
cold = sum(1 for t in tickets if "بارد" in str(t.get("حرارة_العميل", "")))

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{len(tickets)}</div><div class="kpi-label">📊 إجمالي الـ Leads</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#c084fc;">{hot}</div><div class="kpi-label">🔥 ساخن</div></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#a78bfa;">{warm}</div><div class="kpi-label">🌡️ دافئ</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#818cf8;">{cold}</div><div class="kpi-label">❄️ بارد</div></div>', unsafe_allow_html=True)

st.markdown('<hr style="margin:1.2rem 0;"/>', unsafe_allow_html=True)

if not tickets:
    st.info("📭 لا توجد leads بعد. ابدأ محادثة من صفحة Chat Agent!")
    st.stop()

# ── Ticket Cards ──────────────────────────────────────────────────────────────
for t in tickets:
    heat = str(t.get("حرارة_العميل", ""))
    card_class  = "hot" if "ساخن" in heat else ("warm" if "دافئ" in heat else "cold")
    badge_class = f"badge-{card_class}"
    badge_text  = ("🔥 ساخن" if card_class=="hot" else ("🌡️ دافئ" if card_class=="warm" else "❄️ بارد"))

    name    = t.get("الاسم", "—")
    contact = t.get("التواصل", "—")
    city    = t.get("المدينة", "—")
    product = t.get("المنتج_المهتم_به", "—")
    goal    = t.get("الهدف", "—")
    level   = t.get("المستوى_الحالي", "—")
    signals = t.get("إشارات_الشراء", "—")
    obj     = t.get("الاعتراضات", "—")
    summary = t.get("ملخص_المحادثة", "—")
    action  = t.get("الإجراء_التالي", "—")
    created = (t.get("created_at","")[:16] if t.get("created_at") else "—")

    st.markdown(f"""
<div class="ticket-card {card_class}">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <span class="field-name">👤 {name}</span>
        <div style="display:flex;gap:0.6rem;align-items:center;">
            <span class="{badge_class}">{badge_text}</span>
            <span style="color:#4a4070;font-size:0.78rem;">{created}</span>
        </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.7rem;margin-bottom:0.7rem;">
        <div><div class="field-label">📞 التواصل</div><div class="field-value">{contact}</div></div>
        <div><div class="field-label">📍 المدينة</div><div class="field-value">{city}</div></div>
        <div><div class="field-label">🎯 المنتج المهتم به</div><div class="field-value">{product}</div></div>
        <div><div class="field-label">📚 المستوى الحالي</div><div class="field-value">{level}</div></div>
        <div><div class="field-label">🚦 إشارات الشراء</div><div class="field-value">{signals}</div></div>
        <div><div class="field-label">⚠️ الاعتراضات</div><div class="field-value">{obj}</div></div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">🏁 الهدف</div>
        <div class="field-value">{goal}</div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">💬 ملخص المحادثة</div>
        <div class="field-value">{summary}</div>
    </div>
    <div class="action-box">
        <div class="field-label">👉 الإجراء التالي</div>
        <div class="field-value" style="color:#34d399;">{action}</div>
    </div>
</div>
""", unsafe_allow_html=True)

    if t.get("conversation"):
        with st.expander(f"💬 عرض المحادثة الكاملة — {name}"):
            for msg in t["conversation"]:
                role_label = "👤 العميل" if msg["role"] == "user" else "🤖 كيفة"
                align = "right" if msg["role"] == "user" else "left"
                bg    = "rgba(139,92,246,0.1)" if msg["role"] == "user" else "rgba(12,10,30,0.8)"
                st.markdown(f"""
<div style="direction:rtl;text-align:{align};padding:0.6rem 0.9rem;
    background:{bg};border-radius:12px;margin-bottom:0.4rem;
    border:1px solid rgba(139,92,246,0.1);">
    <strong style="color:#a78bfa;">{role_label}</strong><br>
    <span style="color:#e2e8f0;">{msg['content']}</span>
</div>""", unsafe_allow_html=True)