"""
db.py
MongoDB connection and CRM ticket helpers.
"""

import os
from datetime import datetime
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

_client = None
_db = None


def get_db():
    global _client, _db
    if _db is not None:
        return _db
    from dotenv import load_dotenv
    load_dotenv(override=True)
    uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    _client = MongoClient(uri, serverSelectionTimeoutMS=3000)
    _db = _client["kayfa_crm"]
    return _db


def save_ticket(ticket: dict) -> str:
    """Save a CRM ticket and return its string ID."""
    db = get_db()
    ticket["created_at"] = datetime.utcnow().isoformat()
    result = db["leads"].insert_one(ticket)
    return str(result.inserted_id)


def get_all_tickets():
    """Return all CRM tickets sorted newest first."""
    db = get_db()
    tickets = list(db["leads"].find().sort("created_at", -1))
    for t in tickets:
        t["_id"] = str(t["_id"])
    return tickets


def delete_ticket(ticket_id: str) -> bool:
    """Delete a CRM ticket by its string ID."""
    from bson import ObjectId
    db = get_db()
    result = db["leads"].delete_one({"_id": ObjectId(ticket_id)})
    return result.deleted_count > 0


def is_connected() -> bool:
    try:
        get_db().command("ping")
        return True
    except Exception:
        return False