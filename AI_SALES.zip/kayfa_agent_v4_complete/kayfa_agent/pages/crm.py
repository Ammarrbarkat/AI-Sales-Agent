"""
pages/crm.py — CRM Tickets — Unified Purple Theme
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
from pathlib import Path
from db import get_all_tickets, delete_ticket, is_connected

# Local translation function
def t(ar, en):
    return en if st.session_state.get("lang") == "en" else ar

st.set_page_config(page_title="Kayfa CRM", page_icon="📋", layout="wide")

if Path("assets/logo.png").exists():
    st.logo("assets/logo.png")

if not st.session_state.get("authenticated"):
    st.error("🔒 Please log in from the main page first")
    st.stop()

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Cairo', sans-serif; color: #e2e8f0; background: #06050f !important; }

.stApp {
    background:
        radial-gradient(ellipse at 15% 15%, rgba(139,92,246,0.13) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, rgba(99,102,241,0.10) 0%, transparent 45%),
        radial-gradient(ellipse at 50% 0%,  rgba(168,85,247,0.07) 0%, transparent 40%),
        linear-gradient(180deg, #06050f 0%, #0c0a1e 100%) !important;
}
section.main .block-container { padding-top: 0.75rem !important; background: transparent !important; }
section.main, div[data-testid="stMain"] { background: transparent !important; }

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
    background: rgba(10, 8, 28, 0.97) !important;
    border-right: 1px solid rgba(139,92,246,0.25) !important;
}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div,
section[data-testid="stSidebar"] label { color: #c4b5fd !important; }
section[data-testid="stSidebar"] strong { color: #ede9fe !important; }
section[data-testid="stSidebar"] hr     { border-color: rgba(139,92,246,0.2) !important; }
section[data-testid="stSidebar"] a      { color: #a78bfa !important; }
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] {
    border-radius: 10px !important; color: #c4b5fd !important;
}
section[data-testid="stSidebar"] [data-testid="stSidebarNavLink"]:hover {
    background: rgba(139,92,246,0.15) !important;
}
section[data-testid="stSidebar"] [aria-selected="true"] {
    background: rgba(139,92,246,0.2) !important; color: #ede9fe !important;
}

/* ── Unified Logo 48px ── */
[data-testid="stSidebarHeader"] {
    padding: 1.1rem 1rem 0.8rem !important;
    border-bottom: 1px solid rgba(139,92,246,0.2) !important;
    margin-bottom: 0.4rem !important;
}
[data-testid="stLogo"] img,
[data-testid="stSidebarHeader"] img {
    width: 48px !important; height: 48px !important;
    max-width: 48px !important; max-height: 48px !important;
    min-width: 48px !important; min-height: 48px !important;
    object-fit: contain !important; display: block !important;
    margin: 0 auto !important; transform: none !important;
    filter: drop-shadow(0 3px 12px rgba(139,92,246,0.4)) !important;
}

/* ── Header ── */
.page-header {
    background: linear-gradient(135deg, rgba(88,28,135,0.35) 0%, rgba(15,10,40,0.97) 60%);
    padding: 1.6rem 2rem; border-radius: 24px; margin-bottom: 1.6rem;
    border: 1px solid rgba(139,92,246,0.3);
    box-shadow: 0 0 0 1px rgba(139,92,246,0.1), 0 24px 60px rgba(0,0,0,0.4);
}
.page-header h1 { color: #c084fc; margin: 0; font-size: 1.85rem; font-weight: 800; }
.page-header p  { color: #a78bfa; margin: 0.3rem 0 0; font-size: 0.97rem; }

/* ── KPI cards ── */
.kpi-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 20px; padding: 1.3rem 1rem;
    text-align: center; margin-bottom: 1rem;
    transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card:hover { transform: translateY(-2px); box-shadow: 0 12px 40px rgba(139,92,246,0.2); }
.kpi-card .kpi-val       { font-size: 2rem; font-weight: 800; }
.kpi-card .kpi-val.money { color: #34d399; }
.kpi-card .kpi-val.count { color: #a78bfa; }
.kpi-card .kpi-label     { color: #7c6ea8; font-size: 0.88rem; margin-top: 0.25rem; }

/* ── Ticket cards ── */
.ticket-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 22px; padding: 1.4rem 1.6rem;
    margin-bottom: 1.2rem; direction: rtl; text-align: right;
    box-shadow: 0 18px 45px rgba(0,0,0,0.25);
    transition: transform 0.2s, box-shadow 0.2s;
}
.ticket-card:hover { transform: translateY(-2px); box-shadow: 0 24px 60px rgba(139,92,246,0.15); }
.ticket-card.hot  { border-left: 4px solid #c084fc; }
.ticket-card.warm { border-left: 4px solid #a78bfa; }
.ticket-card.cold { border-left: 4px solid #818cf8; }

.badge-hot  { background: linear-gradient(135deg,#7c3aed,#9333ea); color:#fff; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-warm { background: linear-gradient(135deg,#6d28d9,#7c3aed); color:#ddd6fe; padding:5px 14px; border-radius:999px; font-size:0.82rem; font-weight:700; }
.badge-cold { background: rgba(99,102,241,0.2); color:#a5b4fc; padding:5px 14px; border-radius:999px; font-size:0.82rem; border:1px solid rgba(99,102,241,0.3); }

.field-label { color: #7c6ea8; font-size: 0.85rem; }
.field-value { color: #e2e8f0; font-weight: 600; }
.field-name  { color: #c084fc; font-size: 1.1rem; font-weight: 800; }

.action-box {
    background: rgba(139,92,246,0.08); border: 1px solid rgba(139,92,246,0.2);
    border-radius: 12px; padding: 0.7rem 1rem; margin-top: 0.8rem;
}

/* ── Fix column backgrounds ── */
[data-testid="stHorizontalBlock"] { gap: 1rem !important; }
[data-testid="stColumn"] { background: transparent !important; padding: 0 !important; }
[data-testid="stVerticalBlock"] { background: transparent !important; }
div.stColumn > div { background: transparent !important; }

/* Buttons */
section[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #6d28d9, #7c3aed) !important;
    color: #fff !important; border: none !important;
    border-radius: 12px !important; font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(139,92,246,0.3) !important;
}

/* Purple metrics */
[data-testid="stMetricValue"] { color: #a78bfa !important; font-weight: 700 !important; }
[data-testid="stMetricDelta"] { color: #34d399 !important; }
hr { border-color: rgba(139,92,246,0.15) !important; }

/* Expander */
[data-testid="stExpander"] {
    background: rgba(12,10,30,0.95) !important;
    border: 1px solid rgba(139,92,246,0.2) !important;
    border-radius: 14px !important;
}
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    uname = st.session_state.get("username", "")
    role  = st.session_state.get("role", "sales")
    st.markdown(f"""
<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);
    border-radius:14px;padding:0.9rem 1rem;margin-bottom:0.8rem;">
    <div style="color:#c4b5fd;font-size:0.82rem;margin-bottom:0.5rem;">Current User</div>
    <span style="color:#ede9fe;">👤 <strong>{uname}</strong></span><br>
    <span style="font-size:0.85rem;color:#a78bfa;">{'🔴 Admin' if role=='admin' else '🟡 Sales'}</span>
</div>
""", unsafe_allow_html=True)
    if st.button("🚪 Logout", use_container_width=True, key="crm_logout"):
        for k in ["authenticated", "role", "username"]:
            st.session_state[k] = None
        st.switch_page("app_ai.py")
st.markdown("""
<div class="page-header">
    <h1>📋 CRM Dashboard — Kayfa</h1>
    <p>All leads captured from AI Sales Agent conversations</p>
</div>
""", unsafe_allow_html=True)

if not is_connected():
    st.error("🔴 Could not connect to MongoDB. Check MONGODB_URI.")
    st.stop()

tickets = get_all_tickets()

# ── KPI Stats ─────────────────────────────────────────────────────────────────
hot  = sum(1 for t in tickets if "Hot" in str(t.get("حرارة_العميل", "")))
warm = sum(1 for t in tickets if any(x in str(t.get("حرارة_العميل","")) for x in ["دافئ","Warm","Medium Interest"]))
cold = sum(1 for t in tickets if any(x in str(t.get("حرارة_العميل","")) for x in ["بارد","Cold","Low Interest"]))

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count">{len(tickets)}</div><div class="kpi-label">📊 Total Leads</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#c084fc;">{hot}</div><div class="kpi-label">⭐⭐⭐ High Interest</div></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#a78bfa;">{warm}</div><div class="kpi-label">⭐⭐ Medium Interest</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="kpi-card"><div class="kpi-val count" style="color:#818cf8;">{cold}</div><div class="kpi-label">⭐ Low Interest</div></div>', unsafe_allow_html=True)

st.markdown('<hr style="margin:1.2rem 0;"/>', unsafe_allow_html=True)

if not tickets:
    st.info("📭 No leads yet. Start a conversation from the Chat page!")
    st.stop()

# ── Ticket Cards ──────────────────────────────────────────────────────────────
if "confirm_delete" not in st.session_state:
    st.session_state.confirm_delete = None

for t in tickets:
    heat = str(t.get("حرارة_العميل", ""))
    card_class  = "hot" if any(x in heat for x in ["Hot","High Interest","ساخن"]) else ("warm" if any(x in heat for x in ["Warm","Medium Interest","دافئ"]) else "cold")
    badge_class = f"badge-{card_class}"
    badge_text  = ("⭐⭐⭐ High Interest" if card_class=="hot" else ("⭐⭐ Medium Interest" if card_class=="warm" else "⭐ Low Interest"))

    name    = t.get("الاسم", "—")
    contact = t.get("التواصل", "") or t.get("Contact", "") or t.get("رقم_التواصل", "") or "—"
    city    = t.get("City", "—")
    product = t.get("المنتج_المهتم_به", "—")
    goal    = t.get("Goal", "—")
    level   = t.get("المستوى_الحالي", "—")
    signals = t.get("إشارات_الشراء", "—")
    obj     = t.get("Objections", "—")
    summary = t.get("ملخص_المحادثة", "—")
    action  = t.get("الإجراء_التالي", "—")
    created = (t.get("created_at","")[:16] if t.get("created_at") else "—")

    st.markdown(f"""
<div class="ticket-card {card_class}">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <span class="field-name">👤 {name}</span>
        <div style="display:flex;gap:0.6rem;align-items:center;">
            <span class="{badge_class}">{badge_text}</span>
            <span style="color:#4a4070;font-size:0.78rem;">{created}</span>
        </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.7rem;margin-bottom:0.7rem;">
        <div><div class="field-label">📞 Contact</div><div class="field-value">{contact}</div></div>
        <div><div class="field-label">📍 City</div><div class="field-value">{city}</div></div>
        <div><div class="field-label">🎯 Interested In</div><div class="field-value">{product}</div></div>
        <div><div class="field-label">📚 Current Level</div><div class="field-value">{level}</div></div>
        <div><div class="field-label">🚦 Purchase Signals</div><div class="field-value">{signals}</div></div>
        <div><div class="field-label">⚠️ Objections</div><div class="field-value">{obj}</div></div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">🏁 Goal</div>
        <div class="field-value">{goal}</div>
    </div>
    <div style="margin-bottom:0.6rem;">
        <div class="field-label">💬 Conversation Summary</div>
        <div class="field-value">{summary}</div>
    </div>
    <div class="action-box">
        <div class="field-label">👉 Next Action</div>
        <div class="field-value" style="color:#34d399;">{action}</div>
    </div>
</div>
""", unsafe_allow_html=True)

    # ── Conversation + Delete button ──────────────────────────────
    col_conv, col_del = st.columns([6, 1])

    with col_conv:
        if t.get("conversation"):
            with st.expander(f"💬 View Full Conversation — {name}"):
                for msg in t["conversation"]:
                    role_label = "👤 Customer" if msg["role"] == "user" else "🤖 Kayfa Agent"
                    align = "right" if msg["role"] == "user" else "left"
                    bg    = "rgba(139,92,246,0.1)" if msg["role"] == "user" else "rgba(12,10,30,0.8)"
                    st.markdown(f"""
<div style="direction:rtl;text-align:{align};padding:0.6rem 0.9rem;
    background:{bg};border-radius:12px;margin-bottom:0.4rem;
    border:1px solid rgba(139,92,246,0.1);">
    <strong style="color:#a78bfa;">{role_label}</strong><br>
    <span style="color:#e2e8f0;">{msg['content']}</span>
</div>""", unsafe_allow_html=True)

    with col_del:
        ticket_id = t.get("_id", "")
        if st.session_state.confirm_delete == ticket_id:
            st.markdown("**Sure?**")
            if st.button("✅ Yes", key=f"yes_{ticket_id}", use_container_width=True):
                if delete_ticket(ticket_id):
                    st.success("Deleted!")
                    st.session_state.confirm_delete = None
                    st.rerun()
            if st.button("❌ No", key=f"no_{ticket_id}", use_container_width=True):
                st.session_state.confirm_delete = None
                st.rerun()
        else:
            if st.button("🗑️ Delete", key=f"del_{ticket_id}", use_container_width=True):
                st.session_state.confirm_delete = ticket_id
                st.rerun()