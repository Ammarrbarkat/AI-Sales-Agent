"""
pages/admin_dashboard.py — Admin Dashboard: Purple theme + Green for money
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
import base64
from pathlib import Path

st.set_page_config(
    page_title="Kayfa — Admin Dashboard",
    page_icon="📊",
    layout="wide",
)

# ── Fixed-size logo in the sidebar ─────────────────────────────────────────
def get_logo_b64():
    p = Path("assets/logo.png")
    if p.exists():
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode()
    return ""

LOGO = get_logo_b64()

if LOGO:
    st.markdown(f"""
    <style>
    [data-testid="stSidebarHeader"] {{ padding: 0 !important; }}
    [data-testid="stLogo"] {{ display: none !important; }}
    </style>
    """, unsafe_allow_html=True)
    st.logo("assets/logo.png", size="medium")

# ── Auth gate ─────────────────────────────────────────────────────────────────
if not st.session_state.get("authenticated"):
    st.markdown("## 🔒 Please log in from the main page first")
    st.stop()

if st.session_state.get("role") != "admin":
    st.error("⛔ This page is for Admins only")
    st.stop()

# ── CSS — Purple theme + Green for money ────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Cairo', sans-serif;
    color: #e2e8f0;
    background: #06050f !important;
}

/* Purple background */
.stApp {
    background:
        radial-gradient(ellipse at 15% 15%, rgba(139,92,246,0.13) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, rgba(99,102,241,0.10) 0%, transparent 45%),
        radial-gradient(ellipse at 50% 0%,  rgba(168,85,247,0.07) 0%, transparent 40%),
        linear-gradient(180deg, #06050f 0%, #0c0a1e 100%) !important;
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background: rgba(10, 8, 28, 0.97) !important;
    border-right: 1px solid rgba(139,92,246,0.25) !important;
}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div,
section[data-testid="stSidebar"] label { color: #c4b5fd !important; }
section[data-testid="stSidebar"] strong { color: #ede9fe !important; }
section[data-testid="stSidebar"] hr { border-color: rgba(139,92,246,0.2) !important; }

/* Sidebar logo — fixed 48px */
[data-testid="stSidebarHeader"] {
    padding: 1.1rem 1rem 0.8rem !important;
    border-bottom: 1px solid rgba(139,92,246,0.2) !important;
    margin-bottom: 0.5rem !important;
}
[data-testid="stLogo"] img,
[data-testid="stSidebarHeader"] img {
    width:  48px !important;
    height: 48px !important;
    max-width:  48px !important;
    max-height: 48px !important;
    min-width:  48px !important;
    min-height: 48px !important;
    object-fit: contain !important;
    display: block !important;
    margin: 0 auto !important;
    transform: none !important;
    filter: drop-shadow(0 3px 12px rgba(139,92,246,0.4)) !important;
}

/* Page header */
.dash-header {
    background: linear-gradient(135deg,
        rgba(88,28,135,0.35) 0%,
        rgba(15,10,40,0.97) 60%);
    padding: 1.6rem 2rem;
    border-radius: 24px;
    margin-bottom: 1.6rem;
    border: 1px solid rgba(139,92,246,0.3);
    box-shadow:
        0 0 0 1px rgba(139,92,246,0.1),
        0 24px 60px rgba(0,0,0,0.4);
}
.dash-header h1 { color: #c084fc; margin: 0; font-size: 1.85rem; font-weight: 800; }
.dash-header p  { color: #a78bfa; margin: 0.3rem 0 0; font-size: 0.97rem; }

/* Tabs */
button[data-baseweb="tab"] {
    font-family: 'Cairo', sans-serif !important;
    font-weight: 600 !important;
    color: #a78bfa !important;
}
button[data-baseweb="tab"][aria-selected="true"] {
    color: #c084fc !important;
    border-bottom: 3px solid #8b5cf6 !important;
}

/* KPI cards — Green for money */
.kpi-card {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(139,92,246,0.18);
    border-radius: 20px;
    padding: 1.3rem 1rem;
    text-align: center;
    margin-bottom: 1rem;
    transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(139,92,246,0.2);
}
.kpi-card .kpi-val       { font-size: 2rem; font-weight: 800; }
.kpi-card .kpi-val.money { color: #34d399; }   /* Green for money */
.kpi-card .kpi-val.count { color: #a78bfa; }   /* Purple for count */
.kpi-card .kpi-label     { color: #7c6ea8; font-size: 0.88rem; margin-top: 0.25rem; }

/* Cost box */
.cost-box {
    background: rgba(12, 10, 30, 0.95);
    border: 1px solid rgba(52,211,153,0.15);
    border-radius: 18px;
    padding: 1.2rem 1.4rem;
    margin-bottom: 1rem;
    direction: ltr;
}

/* Table inside cost box */
.cost-box table { width: 100%; border-collapse: collapse; }
.cost-box th { color: #a78bfa; font-weight: 700; padding: 0.4rem 0.6rem; border-bottom: 1px solid rgba(139,92,246,0.2); }
.cost-box td { color: #e2e8f0; padding: 0.4rem 0.6rem; }
.cost-box tr:hover td { background: rgba(139,92,246,0.05); }
.cost-box .money-num { color: #34d399; font-weight: 700; }

/* Log rows */
.log-row {
    background: rgba(12,10,30,0.95);
    border: 1px solid rgba(139,92,246,0.12);
    border-radius: 12px;
    padding: 0.6rem 1rem;
    margin-bottom: 0.4rem;
    font-size: 0.86rem;
    direction: ltr;
}
.log-row .money { color: #34d399; font-weight: 700; }
.log-row .opt   { color: #a78bfa; }
.log-row .norm  { color: #7c6ea8; }

/* Trace steps */
.trace-step {
    background: rgba(10,8,25,0.97);
    border-radius: 14px;
    padding: 0.85rem 1rem;
    margin-bottom: 0.6rem;
    border-left: 3px solid #6366f1;
    direction: ltr;
}
.trace-step.tool_call     { border-left-color: #c084fc; }
.trace-step.tool_result   { border-left-color: #34d399; }
.trace-step.reasoning     { border-left-color: #818cf8; }
.trace-step.final_response{ border-left-color: #a78bfa; }
.trace-step strong { color: #e2e8f0; }
.trace-step span   { color: #7c6ea8; }

/* Optimization boxes */
.opt-box {
    background: rgba(139,92,246,0.07);
    border: 1px solid rgba(139,92,246,0.25);
    border-radius: 18px;
    padding: 1.4rem;
    margin-bottom: 1rem;
}
.before-box {
    background: rgba(239,68,68,0.06);
    border: 1px solid rgba(239,68,68,0.2);
    border-radius: 14px;
    padding: 1rem;
    direction: ltr;
}
.after-box {
    background: rgba(52,211,153,0.06);
    border: 1px solid rgba(52,211,153,0.2);
    border-radius: 14px;
    padding: 1rem;
    direction: ltr;
}
.saving-banner {
    text-align: center;
    margin: 1.5rem 0;
    padding: 1.2rem;
    background: rgba(139,92,246,0.1);
    border: 1px solid rgba(139,92,246,0.3);
    border-radius: 18px;
}

/* ── Fix column backgrounds ── */
[data-testid="stHorizontalBlock"] { gap: 1rem !important; }
[data-testid="stColumn"] { background: transparent !important; padding: 0 !important; }
[data-testid="stVerticalBlock"] { background: transparent !important; }
div.stColumn > div { background: transparent !important; }

section[data-testid="stSidebar"] .stButton > button {
    background: linear-gradient(135deg, #6d28d9, #7c3aed) !important;
    color: #fff !important; border: none !important;
    border-radius: 12px !important; font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(139,92,246,0.3) !important;
}

/* Metric override — Green for money */
[data-testid="stMetricValue"] { color: #34d399 !important; font-weight: 700 !important; }

/* divider */
hr { border-color: rgba(139,92,246,0.15) !important; }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="dash-header">
    <h1>📊 Admin Dashboard — Monitoring & Optimization</h1>
    <p>API Cost · Agent Behaviour Trace · Optimization Loop</p>
</div>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    uname = st.session_state.get("username", "")
    st.markdown(f"""
<div style="background:rgba(139,92,246,0.08);border:1px solid rgba(139,92,246,0.2);
    border-radius:14px;padding:0.9rem 1rem;margin-bottom:0.8rem;">
    <div style="color:#c4b5fd;font-size:0.82rem;margin-bottom:0.5rem;">Current Admin</div>
    <span>👤 <strong>{uname}</strong></span><br>
    <span style="font-size:0.85rem;color:#a78bfa;">🔴 Admin</span>
</div>
""", unsafe_allow_html=True)
    if st.button("🚪 Logout", use_container_width=True, key="admin_logout"):
        for k in ["authenticated", "role", "username"]:
            st.session_state[k] = None
        st.switch_page("app_ai.py")

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs([
    "💰 Cost Monitor",
    "🔍 Behaviour Trace",
    "⚡ Optimization",
])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1: COST MONITOR
# ═══════════════════════════════════════════════════════════════════════════════
with tab1:
    st.markdown("### 💰 Full Cost Monitor")

    from cost_tracker import get_cost_stats
    stats = get_cost_stats()

    if "error" in stats:
        st.error(f"⚠️ {stats['error']}")
    else:
        # ── KPI Cards ─────────────────────────────────────────────────────────
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-val count">{stats['total_messages']}</div>
                <div class="kpi-label">📨 Total Messages</div>
            </div>""", unsafe_allow_html=True)
        with c2:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-val money">${stats['total_cost']:.4f}</div>
                <div class="kpi-label">💵 Total Cost</div>
            </div>""", unsafe_allow_html=True)
        with c3:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-val money">${stats['avg_cost_per_message']:.5f}</div>
                <div class="kpi-label">📊 Avg Cost / Msg</div>
            </div>""", unsafe_allow_html=True)
        with c4:
            users_count = len(stats.get("by_user", {}))
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-val count">{users_count}</div>
                <div class="kpi-label">👤 Users</div>
            </div>""", unsafe_allow_html=True)

        st.divider()

        # ── Cost breakdown table ─────────────────────────────────────────────────
        st.markdown("#### 📋 Detailed Cost Calculation Example")
        with st.expander("🔢 How Cost Is Calculated", expanded=True):
            st.markdown("""
<div class="cost-box">
<strong style="color:#c084fc;">Example: Average Conversation — Normal Model</strong><br><br>
<table>
<tr><th>Type</th><th>Tokens</th><th>Price / Million</th><th>Cost</th></tr>
<tr><td>Chat Input (LLaMA-70B)</td><td>8,400</td><td>$0.59/M</td><td class="money-num">$0.004956</td></tr>
<tr><td>Chat Output (LLaMA-70B)</td><td>1,200</td><td>$0.79/M</td><td class="money-num">$0.000948</td></tr>
<tr><td>Embeddings (Keyword)</td><td>0</td><td>$0</td><td class="money-num">$0.000000</td></tr>
<tr style="border-top:1px solid rgba(139,92,246,0.3)">
  <td><strong>Total</strong></td><td><strong>9,600</strong></td><td>—</td>
  <td><strong class="money-num">$0.005904</strong></td>
</tr>
</table>
<br>
<strong style="color:#34d399;">⚡ Optimized Model (LLaMA-8B)</strong><br><br>
<table>
<tr><th>Type</th><th>Tokens</th><th>Price / Million</th><th>Cost</th></tr>
<tr><td>Chat Input (LLaMA-8B)</td><td>3,200</td><td>$0.05/M</td><td class="money-num">$0.000160</td></tr>
<tr><td>Chat Output (LLaMA-8B)</td><td>800</td><td>$0.08/M</td><td class="money-num">$0.000064</td></tr>
<tr style="border-top:1px solid rgba(52,211,153,0.3)">
  <td><strong>Total</strong></td><td><strong>4,000</strong></td><td>—</td>
  <td><strong class="money-num">$0.000224</strong></td>
</tr>
</table>
<br>
<div style="text-align:center;padding:0.6rem;background:rgba(52,211,153,0.08);border-radius:10px;">
🎯 <strong style="color:#34d399;">Saving Rate: ~96.2%</strong>
</div>
</div>
""", unsafe_allow_html=True)

        # ── Cost per user ────────────────────────────────────────────────────────
        if stats.get("by_user"):
            st.markdown("#### 👤 Cost by User")
            for uid, udata in stats["by_user"].items():
                cols = st.columns([2, 1, 1, 1, 1])
                cols[0].markdown(f"**{uid}**")
                cols[1].metric("messages",        udata["messages"])
                cols[2].metric("Cost",        f"${udata['total_cost']:.4f}")
                cols[3].metric("Input Tokens",  f"{udata['input_tokens']:,}")
                cols[4].metric("Output Tokens", f"{udata['output_tokens']:,}")

        st.divider()

        # ── Recent Logs ───────────────────────────────────────────────────────
        st.markdown("#### 📜 Recent Logs")
        recent = stats.get("recent_logs", [])
        if recent:
            for r in recent[:10]:
                opt_label = '<span class="opt">⚡ Optimized</span>' if r.get("optimized") else '<span class="norm">🔵 Normal</span>'
                st.markdown(f"""
<div class="log-row">
⏰ {r.get('timestamp','')[:16]} &nbsp;|&nbsp;
👤 {r.get('user_id','?')} &nbsp;|&nbsp;
{opt_label} &nbsp;|&nbsp;
🤖 {r.get('model','?')} &nbsp;|&nbsp;
📥 {r.get('input_tokens',0):,} / {r.get('output_tokens',0):,} out &nbsp;|&nbsp;
<span class="money">💵 ${r.get('total_cost',0):.6f}</span>
</div>
""", unsafe_allow_html=True)
        else:
            st.info("📭 No cost logs yet. Start a conversation from the Chat page!")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2: BEHAVIOUR TRACE
# ═══════════════════════════════════════════════════════════════════════════════
with tab2:
    st.markdown("### 🔍 Behaviour & Response Trace")
    st.info("💡 Start a conversation on the Chat page, then return here to see the agent's reasoning steps.")

    last_trace = st.session_state.get("last_trace", [])
    last_cost  = st.session_state.get("last_cost", {})

    if last_trace:
        st.markdown("#### 🧠 Last Conversation — Thinking Steps")

        col1, col2, col3 = st.columns(3)
        col1.metric("🤖 Model",  last_cost.get("model", "—"))
        col2.metric("⏱️ Time",    f"{last_cost.get('elapsed_s', 0)}s")
        col3.metric("💵 Cost",  f"${last_cost.get('total_cost', 0):.6f}")

        st.markdown("---")
        for step in last_trace:
            step_type     = step.get("type", "reasoning")
            icon          = step.get("icon", "•")
            title         = step.get("step", "")
            detail        = step.get("detail", "")
            sources       = step.get("sources", [])
            lead_captured = step.get("lead_captured", False)
            tokens_est    = step.get("tokens", "")

            extra = ""
            if sources:      extra += f"<br>📁 Sources: {', '.join(sources)}"
            if lead_captured: extra += "<br>✅ Lead captured!"
            tokens_str = f" | ~{tokens_est:,} tokens" if tokens_est else ""

            st.markdown(f"""
<div class="trace-step {step_type}">
    <strong>{icon} {title}</strong><br>
    <span style="font-size:0.9rem;">{detail}{tokens_str}{extra}</span>
</div>
""", unsafe_allow_html=True)

        st.markdown("---")
        st.markdown("#### 💰 Cost Details for This Message")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Input Tokens",  f"{last_cost.get('input_tokens', 0):,}")
        c2.metric("Output Tokens", f"{last_cost.get('output_tokens', 0):,}")
        c3.metric("Input Cost",    f"${last_cost.get('input_cost', 0):.6f}")
        c4.metric("Output Cost",   f"${last_cost.get('output_cost', 0):.6f}")

        st.markdown(f"""
<div class="cost-box" style="text-align:center;margin-top:0.8rem;">
    <strong style="font-size:1.3rem;color:#34d399;">
        Total Cost: ${last_cost.get('total_cost', 0):.6f}
    </strong><br>
    <span style="color:#7c6ea8;">
        ${last_cost.get('input_price_per_M',0)}/M input · ${last_cost.get('output_price_per_M',0)}/M output
    </span>
</div>
""", unsafe_allow_html=True)

    else:
        st.markdown("""
<div class="cost-box" style="text-align:center;padding:2.5rem;">
    <div style="font-size:3rem;margin-bottom:0.5rem;">🤖</div>
    <div style="color:#7c6ea8;">No trace yet.<br>Go to the Chat page.</div>
</div>
""", unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("#### 📜 Previous Conversations")
    try:
        from db import get_db
        db = get_db()
        cost_logs = list(db["cost_logs"].find(
            {"trace_steps": {"$exists": True, "$ne": []}},
            {"_id": 0}
        ).sort("timestamp", -1).limit(5))

        if cost_logs:
            for log in cost_logs:
                with st.expander(
                    f"⏰ {log.get('timestamp','')[:16]} | "
                    f"👤 {log.get('user_id','?')} | "
                    f"💵 ${log.get('total_cost',0):.6f}"
                ):
                    for step in log.get("trace_steps", []):
                        st.markdown(f"- **{step.get('icon','')} {step.get('step','')}** — {step.get('detail','')}")
        else:
            st.info("No trace logs stored yet.")
    except Exception as e:
        st.warning(f"Could not read logs: {e}")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3: OPTIMIZATION
# ═══════════════════════════════════════════════════════════════════════════════
with tab3:
    st.markdown("### ⚡ Optimization Loop — Close the Loop")

    st.markdown("""
<div class="opt-box">
    <strong style="color:#c084fc;font-size:1.1rem;">✅ Applied Improvements:</strong>
    <ol style="margin-top:0.7rem;color:#ddd6fe;">
        <li><strong> the System Prompt</strong> — from ~900 words to ~80 words ( 91%)</li>
        <li><strong>  </strong> — LLaMA-70B → LLaMA-8B ( 91.5%   the token)</li>
        <li><strong>Selective RAG</strong> — Keyword instead of Embeddings (<span style="color:#34d399;">$0</span> instead of $0.13/M)</li>
        <li><strong>max_tokens limit</strong> — 800 instead of 1000 in Optimized mode</li>
    </ol>
</div>
""", unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### 🔴 Before Optimization")
        st.markdown("""
<div class="before-box">
<table style="width:100%;color:#fca5a5;">
<tr><td>🤖 Model</td><td><strong>llama-3.3-70b-versatile</strong></td></tr>
<tr><td>📥 Input Price</td><td><strong>$0.59 / 1M tokens</strong></td></tr>
<tr><td>📤 Output Price</td><td><strong>$0.79 / 1M tokens</strong></td></tr>
<tr><td>📝 System Prompt</td><td><strong>~900 words (≈3,600 tokens)</strong></td></tr>
<tr><td>🔢 Input per msg</td><td><strong>~8,400 tokens</strong></td></tr>
<tr><td>🔢 Output per msg</td><td><strong>~1,200 tokens</strong></td></tr>
<tr><td>💵 Message cost</td><td><strong style="color:#f87171;">$0.005904</strong></td></tr>
<tr><td>💵 100 message</td><td><strong style="color:#f87171;">$0.5904</strong></td></tr>
<tr><td>💵 1,000 message</td><td><strong style="color:#f87171;">$5.904</strong></td></tr>
</table>
</div>
""", unsafe_allow_html=True)

    with col2:
        st.markdown("#### 🟢 After Optimization")
        st.markdown("""
<div class="after-box">
<table style="width:100%;color:#a7f3d0;">
<tr><td>🤖 Model</td><td><strong>llama-3.1-8b-instant</strong></td></tr>
<tr><td>📥 Input Price</td><td><strong>$0.05 / 1M tokens</strong></td></tr>
<tr><td>📤 Output Price</td><td><strong>$0.08 / 1M tokens</strong></td></tr>
<tr><td>📝 System Prompt</td><td><strong>~80 words (≈320 tokens)</strong></td></tr>
<tr><td>🔢 Input per msg</td><td><strong>~3,200 tokens</strong></td></tr>
<tr><td>🔢 Output per msg</td><td><strong>~800 tokens</strong></td></tr>
<tr><td>💵 Message cost</td><td><strong style="color:#34d399;">$0.000224</strong></td></tr>
<tr><td>💵 100 message</td><td><strong style="color:#34d399;">$0.0224</strong></td></tr>
<tr><td>💵 1,000 message</td><td><strong style="color:#34d399;">$0.224</strong></td></tr>
</table>
</div>
""", unsafe_allow_html=True)

    st.markdown("""
<div class="saving-banner">
    <span style="font-size:2rem;font-weight:800;color:#c084fc;">saving: ~96.2%</span><br>
    <span style="color:#a78bfa;"> <s style="color:#f87171;">$5.904</s> 
    <strong style="color:#34d399;">$0.224</strong>  1,000 message</span>
</div>
""", unsafe_allow_html=True)

    # ──     ─────────────────────────────────────────────
    try:
        from db import get_db
        db = get_db()
        opt_logs    = list(db["cost_logs"].find({"optimized": True},  {"_id": 0}))
        normal_logs = list(db["cost_logs"].find({"optimized": False}, {"_id": 0}))

        if opt_logs or normal_logs:
            st.markdown("#### 📈 Real Comparison from Your Data")
            col1, col2, col3 = st.columns(3)
            avg_normal  = sum(r.get("total_cost",0) for r in normal_logs)  / max(len(normal_logs),1)
            avg_opt     = sum(r.get("total_cost",0) for r in opt_logs)     / max(len(opt_logs),1)
            saving_pct  = ((avg_normal - avg_opt) / avg_normal * 100) if avg_normal > 0 else 0

            col1.metric("🔵  Normal",   f"${avg_normal:.6f}", f"{len(normal_logs)} message")
            col2.metric("⚡  Optimized",  f"${avg_opt:.6f}",   f"{len(opt_logs)} message")
            col3.metric("🎯 saving ", f"{saving_pct:.1f}%")
    except Exception:
        pass

    st.divider()
    st.markdown("#### 📝 Applied Optimization Summary")
    st.markdown("""
**:** The full System Prompt (~3,600 tokens)     message   .

** :**
- **System Prompt Reduction** —   900 → 80 words (saving 91%  the input tokens)
- **Model Routing** — `llama-8b` instead of `llama-70b`   ($0.05 instead of $0.59/M)
- **Keyword RAG** — instead of Embeddings ($0 instead of $0.13/M tokens)

**Result:**  1,000 message  **$5.904** → **$0.224** (saving **96.2%**)
""")